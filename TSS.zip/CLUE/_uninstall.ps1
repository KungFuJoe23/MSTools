#_# File: _uninstall.ps1 adjusted for TSS package - 2020.09.13 /walterE #_#
#_#   Note: xperf.exe,perfctrl.dll and Poolmon.exe are are left in %Windir%\system32
param([string] $IsSilentInstallation = 'false')

# This code is Copyright (c) 2016 Microsoft Corporation.
#
# All rights reserved.
#
# THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
# �INCLUDING BUT NOT LIMITED To THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
#  PARTICULAR PURPOSE.'
#
# IN NO EVENT SHALL MICROSOFT AND/OR ITS RESPECTIVE SUPPLIERS BE LIABLE FOR ANY SPECIAL, INDIRECT OR 
# �CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
#  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION 
# �WITH THE USE OR PERFORMANCE OF THIS CODE OR INFORMATION.

[string] $Log = ([System.Environment]::ExpandEnvironmentVariables('%TEMP%') + '\ClueSetup.log')
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null

#region  ::::: [Functions] -----------------------------------------------------------#
#////////////////
#// Functions //
#//////////////

Function Test-Numeric #_# added
{
    param($Value)
    [double] $number = 0
    Return [double]::TryParse($Value, [REF]$number)
}
Function ConvertTo-DataType	#_# added
{
	param([double] $ValueAsDouble, [string] $DataTypeAsString = 'integer')
	$sDateType = $DataTypeAsString.ToLower()
    If ((Test-Numeric -Value $ValueAsDouble) -eq $True)
    {
    	switch ($sDateType)
    	{
    		'integer' {[Math]::Round($ValueAsDouble,0)}
    		'round1' {[Math]::Round($ValueAsDouble,1)}
    		'round2' {[Math]::Round($ValueAsDouble,2)}
    		'round3' {[Math]::Round($ValueAsDouble,3)}
    		'round4' {[Math]::Round($ValueAsDouble,4)}
    		'round5' {[Math]::Round($ValueAsDouble,5)}
    		'round6' {[Math]::Round($ValueAsDouble,6)}
    		default {$ValueAsDouble}
    	}
    }
    Else
    {
        $ValueAsDouble
    }
}
Function Write-Log
{
    param($Output)
    #// Writes to the log file.
    $TimeStamp = "$(Get-Date -format yyyyMMdd-HHmmss)"

    if ($Output -eq $null) {Add-content $Log -value ('[' + $TimeStamp + '] NULL') -Encoding Unicode;Return}
    switch ($Output.GetType().FullName)
    {
        'System.String'                {Add-content -Path $Log -value ('[' + $TimeStamp + '] ' + $Output) -Encoding Unicode}
        default                        {Add-content -Path $Log -value ('[' + $TimeStamp + ']') -Encoding Unicode; $Output >> $Log}
    }
}

Function Test-Error
{
    param($Err)
    #// Tests if an error condition exists and writes it to the log.
    if ($Err.Count -gt 0)
    {
        Write-Log ('[Test-Error] Error(s) found: ' + $Err.Count)
        Write-Log ($Err)
        $Err.Clear()
    }
}

Function Test-Property
{
	param ([Parameter(Position=0,Mandatory=1)]$InputObject,[Parameter(Position=1,Mandatory=1)]$Name)
	[Bool](Get-Member -InputObject $InputObject -Name $Name -MemberType *Property)
}

Function Write-Console
{
    param([string] $sLine, [bool] $bNoNewLine = $false, [bool] $bAddDateTime = $true, [bool] $IsSilentInstallation = $false)
    Write-Log ($sLine)

    if ($IsSilentInstallation -eq $false)
    {
        $TimeStamp = "$(Get-Date -format yyyyMMdd-HHmmss)"
        if ($bAddDateTime -eq $true)
        {
            [string] $sOutput = '[' + $TimeStamp + '] ' + $sLine
        }
        else
        {
            [string] $sOutput = $sLine
        }

        if ($bNoNewLine -eq $false)
        {
            Write-Host $sOutput
        }
        else
        {
            Write-Host $sOutput -NoNewline
        }        
    }    
}

Function Write-MsgBox
{
    param([string] $sLine, [bool] $IsSilentInstallation = $false)    
    if ($IsSilentInstallation -eq $false)
    {
        Write-Console ('[PopUp] ' + $sLine)
        [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
        [void] [Microsoft.VisualBasic.Interaction]::MsgBox($sLine, 0, 'Tool configuration')
    }
}

Function Set-OverallProgress
{
    param([string] $Status='')

    $global:iOverallCompletion++
    $iPercentComplete = ConvertTo-DataType -ValueAsDouble $(($global:iOverallCompletion / 13) * 100) -DataTypeAsString 'integer' -ErrorAction SilentlyContinue #_# -EA
    If ($iPercentComplete -gt 100){$iPercentComplete = 100}
    $sComplete = "Clue installation progress: $iPercentComplete%... $Status"
    Write-Progress -activity 'Progress: ' -status $sComplete -percentcomplete $iPercentComplete -id 1;
    $global:oOverallProgress = 'Overall progress... Status: ' + "$($Status)" + ', ' + "$($sComplete)"
}

function Get-OutputDirectory
{
    param($XmlConfig)
    Write-Log ('[Get-OutputDirectory]: START')
    [bool] $IsDone = $false
    [string] $OutputDirectory = Get-XmlAttribute -XmlNode $XmlConfig -Name 'OutputDirectory'
    if ($OutputDirectory -eq '')
    {
        [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
        $sResponse = ''
        if ($IsSilentInstallation -eq $false)
        {
            [int] $Yes = 6; [int] $No = 7;

            while ($sResponse -eq '')
            {
                Write-Console '[PopUp] Waiting for user response...' -bNoNewLine $true -bAddDateTime $false
                $sResponse = [Microsoft.VisualBasic.Interaction]::InputBox('This is where output files will go. Several gigabytes might be necessary.', 'Clue tool - Output Directory', 'C:\ClueOutput')
                Write-Log ('UserResponse: ' + $sResponse)

                if ($sResponse -eq '')
                {
                    $iYesNo = [Microsoft.VisualBasic.Interaction]::MsgBox('Are you sure you?', 4, 'Clue tool - Cancel Installation')
                }

                if ($iYesNo -eq $Yes)
                {
                    Exit;
                }

                while ($sResponse.Contains(' '))
                {
                    $sResponse = $sResponse.Replace(' ','')
                    $sResponse = [Microsoft.VisualBasic.Interaction]::InputBox('Please provide a folder path without spaces. This is due to how the Task Scheduler handles parameters.', 'Clue tool - Output Directory - Try Again', $sResponse)
                    Write-Log ('UserResponse: ' + $sResponse)
                }
            }
        }

        if ($sResponse -eq '')
        {
            Write-Console ('!!!ERROR!!! Unable to continue without an output directory. Setup has failed.')
            if ($IsSilentInstallation -eq 'false')
            {
                Write-MsgBox ('Unable to continue without an output directory. Setup has failed!')
            }
            Break;
        }

        $IsDone = New-DirectoryWithConfirm -DirectoryPath $sResponse
        if ($IsDone -eq $true)
        {
            $OutputDirectory = $sResponse
            Write-Log ("`t" + 'Output folder "' + $OutputDirectory + '" created or already exists.')
        }
        else
        {
            Write-Console ('!!!ERROR!!! Unable to create output directory ' + $sResponse + '"')
            Break;
        }
    }
    Write-Log ("`t" + 'OutputDirectory: "' + $OutputDirectory + '"')
    Write-Log ('[Get-OutputDirectory]: END')
    Return $OutputDirectory
}

function Get-UploadNetworkShare
{
    param($XmlConfig)
    Write-Log ('[Get-UploadNetworkShare]: START')
    $UploadNetworkShare = Get-XmlAttribute -XmlNode $XmlConfig -Name 'UploadNetworkShare'
    if ($UploadNetworkShare -eq '')
    {
        [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
        [int] $Yes = 6; [int] $No = 7;
        $sResponse = ''
        if ($IsSilentInstallation -eq $false)
        {
            Write-Console '[PopUp] Waiting for user response...' -bNoNewLine $true -bAddDateTime $false
            $sResponse = [Microsoft.VisualBasic.Interaction]::InputBox('This is the network share (\\server\share) where Clue will upload incident data and download updates. Grant the SYSTEM account of this computer read/write access to the network share. Leave blank if this is a stand-alone installation.', 'Clue tool - Network Share', '')
            Write-Log ('UserResponse: ' + $sResponse)
        }
        
        if ($sResponse -ne '')
        {
            $UploadNetworkShare = $sResponse
        }
    }
    Write-Log ("`t" + 'UploadNetworkShare: "' + $global:UploadNetworkShare + '"')
    Write-Log ('[Get-UploadNetworkShare]: END')
    Return $UploadNetworkShare
}

Function Get-EmailForReport
{
    param($XmlConfig)
    Write-Log ('[Get-EmailForReport]: START')
    $EmailReportTo = Get-XmlAttribute -XmlNode $XmlConfig -Name 'EmailReportTo'
    if ($EmailReportTo -eq '')
    {
        $sResponse = ''
        if ($IsSilentInstallation -eq $false)
        {
            Write-Console '[PopUp] Waiting for user response...' -bNoNewLine $true -bAddDateTime $false
            $sResponse = [Microsoft.VisualBasic.Interaction]::InputBox('What email addresses (separated by semi-colon (;)) do you want the report sent to?', 'Clue tool - Email report to...', '')
            Write-Log ('UserResponse: ' + $sResponse)
        }
        
        if ($sResponse -ne '')
        {
            $EmailReportTo = $sResponse
        }
    }
    Write-Log ("`t" + 'EmailReportTo: "' + $EmailReportTo + '"')
    Write-Log ('[Get-EmailForReport]: END')
    Return $EmailReportTo
}

Function Invoke-MyCmd
{
    param([string] $Cmd)
    Write-Log ($Cmd)
    $Output = Invoke-Expression -Command $Cmd
    Write-Log ($Output)
    Test-Error -Err $Error
}

Function Get-TaskSchedulerService
{
    try
    {
        $oTaskSchedulerService = New-Object -ComObject 'Schedule.Service'
        $oTaskSchedulerService.Connect()
        Return $oTaskSchedulerService
    }
    catch
    {
        Return $null
    }
}

Function Get-Ps2ScheduledTaskFolder
{
    param([string] $Path)

    $oTaskSchedulerService = Get-TaskSchedulerService

    if ($oTaskSchedulerService -eq $null)
    {
        Return $null
    }

    try
    {
        $oTaskSchedulerFolder = $oTaskSchedulerService.GetFolder($Path)
    }
    catch
    {

    }

    if ($oTaskSchedulerFolder -ne $null)
    {
        Return $oTaskSchedulerFolder
    }
    
    if ($Path.Contains('\'))
    {
        $aPath = $Path.Split('\',[StringSplitOptions]'RemoveEmptyEntries')
    }
    else
    {
        Return $null
    }
    
    [int] $iCount = 0
    For ($i = 0; $i -le $aPath.GetUpperBound(0); $i++)
    {
        [string] $sBuildPath = $sBuildPath + '\' + $aPath[$i]

        try
        {
            Write-Log ('sBuildPath: ' + $sBuildPath)
            $oTaskSchedulerFolder = $oTaskSchedulerService.GetFolder($sBuildPath)
        }
        catch
        {
            try
            {
                #// Get the parent path and create it.
                if ($oTaskSchedulerParentFolder -ne $null)
                {
                    $oTaskSchedulerFolder = $oTaskSchedulerParentFolder.CreateFolder($aPath[$i])
                }
                else
                {
                    Return $null
                }
            }
            catch
            {
                Return $null
            }
        }
        finally
        {
            $oTaskSchedulerParentFolder = $oTaskSchedulerFolder
        }
        $iCount++
    }

    if ($iCount -eq $aPath.Count)
    {
        Return $oTaskSchedulerFolder
    }
    else
    {
        Return $null
    }
}

Function Get-WorkingDirectoryFromTask
{
    param([string] $ScheduledTaskFolderPath = '\Microsoft\Windows\Clue', [string] $TaskName = 'Invoke-Rule')
    $oTaskFolder = Get-Ps2ScheduledTaskFolder -Path $ScheduledTaskFolderPath
    if ($oTaskFolder -eq $null)
    {
        Return ''
    }
    try {$oTask = $oTaskFolder.GetTask($TaskName)} catch {}
    if ($oTask -eq $null)
    {
        Return ''
    }
    foreach ($oAction in $oTask.Definition.Actions)
    {
        [string] $WorkingDirectory = $oAction.WorkingDirectory
        if ($WorkingDirectory.Length -gt 0)
        {
            Return $WorkingDirectory
        }
    }
    Return ''
}

Function Remove-AllScheduledTasksInToolFolder
{
    $oTaskSchedulerService = Get-TaskSchedulerService
    Test-Error -Err $Error

    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get task folder "\Microsoft\Windows\Clue": START')
    $oTaskSchedulerFolder = $null
    $oParentTaskSchedulerFolder = $oTaskSchedulerService.GetFolder('\Microsoft\Windows')
    $oFolders = $oParentTaskSchedulerFolder.GetFolders(0)
    :FolderLoop foreach ($oFolder in $oFolders)
    {
        if ($oFolder.Name -eq 'Clue')
        {
            $oTaskSchedulerFolder = $oFolder
            Break FolderLoop;
        }        
    }

    if ($oTaskSchedulerFolder -eq $null)
    {
        Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get task folder "\Microsoft\Windows\Clue": END')
        Return $null
    }

    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get task folder "\Microsoft\Windows\Clue": END')

    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get tasks of "\Microsoft\Windows\Clue": START')
    $oTasks = $oTaskSchedulerFolder.GetTasks(0)
    Test-Error -Err $Error
    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get tasks of "\Microsoft\Windows\Clue": END')

    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete tasks of "\Microsoft\Windows\Clue": START')
    ForEach ($oTask in $oTasks)
    {
        $oTask.Stop(0)
        Test-Error -Err $Error
        Start-Sleep -Seconds 2
        Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete task "\Microsoft\Windows\Clue\' + $oTask.Name + '": START')
        $oTaskSchedulerFolder.DeleteTask($oTask.Name, 0)
        Test-Error -Err $Error
        Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete task "\Microsoft\Windows\Clue\' + $oTask.Name + '": END')
        Write-Console '.' -bNoNewLine $true -bAddDateTime $false
    }
    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete tasks of "\Microsoft\Windows\Clue": END')
    
    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get task folder "\Microsoft\Windows\Clue": START')
    $oTaskSchedulerFolder = $oTaskSchedulerService.GetFolder('\Microsoft\Windows')
    Test-Error -Err $Error
    Write-Log ('[Remove-AllScheduledTasksInToolFolder] Get task folder "\Microsoft\Windows\Clue": END')

    if ($oTaskSchedulerFolder -is [System.__ComObject])
    {
        Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete "\Microsoft\Windows\Clue": START')
        $oTaskSchedulerFolder.DeleteFolder('Clue', 0)
        Test-Error -Err $Error
        Write-Log ('[Remove-AllScheduledTasksInToolFolder] Delete "\Microsoft\Windows\Clue": END')
    }
}

function Remove-InstallationFolder
{
    param([string] $FolderPath)
    if ((Test-Path -Path $FolderPath) -eq $true)
    {
        $oCollectionOfFilesAndFolders = Get-ChildItem $FolderPath
        foreach ($oFileOrFolder in $oCollectionOfFilesAndFolders)
        {
            If ($oFileOrFolder -is [System.IO.FileInfo])
            {
                Remove-Item -Path $oFileOrFolder.FullName -Force
            }
        }
        $oCollectionOfFilesAndFolders = Get-ChildItem $FolderPath
        foreach ($oFileOrFolder in $oCollectionOfFilesAndFolders)
        {
            If ($oFileOrFolder -is [System.IO.DirectoryInfo])
            {
                Remove-InstallationFolder -FolderPath $oFileOrFolder.FullName
            }
        }
        Remove-Item -Path $FolderPath -Recurse -Force
    }
}
#endregion  ::::: [Functions] --------------------------------------------------------#

#region  ::::: [MAIN] ----------------------------------------------------------------#
#///////////
#// Main //
#/////////

New-Item -Path $Log -ItemType File -Force | Out-Null
Write-Log ('[Setup]: Start')
$Error.Clear()

Write-Console (Get-Location).Path
$InvocationFolderPath = ($SCRIPT:MyInvocation.MyCommand.Path) -replace '\\_uninstall.ps1',''
Write-Console ('InvocationFolderPath: ' + $InvocationFolderPath)

[bool] $IsSilentInstallation = [System.Convert]::ToBoolean($IsSilentInstallation)
[string] $global:ToolName = 'Clue'
[string] $global:ScheduledTaskFolderPath = "\Microsoft\Windows\$global:ToolName"

Write-Log ('IsSilentInstallation = ' + $IsSilentInstallation.ToString())
Write-Console '//////////////////////////'
Write-Console '// Clue tool uninstall //'
Write-Console '////////////////////////'
Write-Console ''

#// Run OnUninstall rule
#.\Invoke-Rule.ps1 -RuleName 'OnUninstall' -Force $true

$InstallationDirectory = Get-WorkingDirectoryFromTask
Test-Error -Err $Error

Write-Console ''
Write-Console '/////////////////////////////'
Write-Console '// Delete scheduled tasks //'
Write-Console '////////////////////////////'
Write-Console ''
Write-Console 'Deleting scheduled tasks...' -bNoNewLine $true
Remove-AllScheduledTasksInToolFolder
Test-Error -Err $Error
Write-Console 'Done!' -bAddDateTime $false

[string] $sTextFilePath = $(Get-Content env:PUBLIC) + '\Documents\ClueUserInitiated.txt'
if (Test-Path -Path $sTextFilePath)
{
    Remove-Item -Path $sTextFilePath -Force -ErrorAction SilentlyContinue
}

Write-Console ''
Write-Console '////////////////////'
Write-Console '// PAL Collector //'
Write-Console '//////////////////'
Write-Console ''
if (Test-Path -Path $InstallationDirectory\PalCollector\_uninstall.ps1)
{	Write-Log ('[PAL-Collector-Remove]: Start')	#_'#
    & $InstallationDirectory\PalCollector\_uninstall.ps1 -Log $Log
    Test-Error -Err $Error
	Write-Log ('[PAL-Collector-Remove]: End')	#_'#
} else {
	Write-Log ('[PAL-Collector-Remove]: $InstallationDirectory\PalCollector\_uninstall.ps1 not found')	#_'#
	}

Write-Console '//////////////////////////'
Write-Console '// Installation folder //'
Write-Console '////////////////////////'
if ($InstallationDirectory -eq '')
{
    $InstallationDirectory = 'C:\ProgramData\Clue'
}

#// Remove the ClueUserInitiatedDataCollector.bat file #_# ClueUserInitiated.bat
#_#$xUserInitiatedPath = ($env:PUBLIC + '\Desktop\ClueUserInitiatedDataCollector.bat')
$xUserInitiatedPath = ($env:PUBLIC + '\Desktop\ClueUserInitiated.bat')
Remove-Item -Path $xUserInitiatedPath -ErrorAction SilentlyContinue

Write-Log ('[Remove-InstallationFolder]: Start')
Remove-InstallationFolder -FolderPath $InstallationDirectory
Test-Error -Err $Error
Write-Log ('[Remove-InstallationFolder]: End')

Set-OverallProgress -Status 'Scheduled tasks...'
Write-Console ''
Write-Console '//////////////////'
Write-Console '// WMI Tracing //'
Write-Console '/////////////////'
Write-Console ''
Write-Console 'Disabling WMI EventLog Tracing...' -bNoNewLine $true
[string] $sCmd = 'Wevtutil.exe sl Microsoft-Windows-WMI-Activity/Trace /e:false /q:true'
$oOutput = Invoke-Expression -Command $sCmd
Write-Log ($oOutput) -Log $Log
Test-Error -Err $Error -Log $Log
Write-Console 'Done!' -bAddDateTime $false

#// Finalize setup.
Write-Console '[PopUp] Please acknowledge uninstall has finished...' -bNoNewLine $true
[string] $FinalMessage = ('Uninstall is finished! For details see ' + $Log)
Write-Console ''
Write-Console '////////////'
Write-Console '// DONE! //'
Write-Console '//////////'
Write-Console ''
Write-MsgBox $FinalMessage
Write-Console 'Done!' -bAddDateTime $false
Write-Log ('[Setup]: End')
#endregion  ::::: [MAIN] -------------------------------------------------------------#
# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDqPAsFNE6VqdDN
# at8ehSjXb2lv03ZliPDQJlcQahObpKCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgonI2ki8z
# ev9VBh6b/hFEvBxQiTd5ACQ8GoLrXD0HVGUwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAF6stp4calc2YXstIuZZ6EpaifumXBlTms8CE8k6HcLFQ/L4NPtLEdKl
# 5SxXUA3OZ3ayO8JRtxO/UH0ZLNYeVvN+UsLb1q0AT2LuKyIzk+0NZoNZhrarQs+v
# aZcPJIP4CGT5KywCPS5Unmrhdm0XX6gG4wAZOmASMUo+GVCkMgfrWvUwXPA0Vrtq
# le5Nuh/uYFOYiqS88AGnj7OBZ3qr7nqZR6Yw85AmKXpOz8mNKOueQAvNT9xFlg1T
# RkynAynSFbIu7kOG6MQMpjlhQjz4Mt2sx3CphlGHnO6DIWYqf4T15dfHN1uRtpW9
# Gg0OPVjOHzixJ7eSCqevgluKwZcmT3ShghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQglJEChppJad3CqFH/5F1z2n3B7tu7PBSDJIZZ4SrL8l4CBmDTn0dh
# nBgTMjAyMTA3MTUxNTQ1MzkuMzI2WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjBB
# NTYtRTMyOS00RDREMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFbfLC6NGc3wacAAAAAAVswDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE2WhcNMjIwNDExMTkwMjE2WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjBBNTYtRTMyOS00RDRE
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyCR/pez12qF6y6YuW2eXqXCOIPWOH4in
# P/qPmrkJDNKdtpW6jgqIKJKmvla2qpWUPudP/dZfpXq9yk1BXlx21VXBp82kuffI
# X59E2hRaHVD27xcaJJfxjNVLyrrwk8WJE7gczMyksJpKNx9Bkh3oKK6TItCu4qdI
# XB0aEzETsYJrJpDxkPIQ8ez8LbHgABgwWxU6yxJ1HyNvx/MB6TdI2Vm1Up3QpvyK
# j7deRDngy9RdX1xUvX94N1dVUEGo6EfOgmzL5zbL+zdb6ARfxBv079uMGRHqEho7
# AQDDs27jT9MxV/BcnuDlH8c1cK3tzghqM03hb4K6B7KwudhupGZb6QIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFGXnLTWIbbdTIF1Mf/XlOcmYuqsuMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAKczazumExqZzhB1WiWs7VldGIMxRV2C73/KryDuQhWX
# 5+SVRXZWWi63r5+k6oAad7Ay3B6cW1qBWFUnwdq7w3CT4gCEHQHTgOhs0PDu/goR
# MBF/wo3yBMfoHtGMeGt4wNaDuJxXQOyiPwwgDwCKtaXB/ievykofSfasROx4EkNZ
# zd1tTQhMkQfVHMWEaRbsjM09AI7XrlOns0udeniZpnOhXHw/KI407p/INmvTKpW6
# H06pYf589lhD9hgXKHHL6EdY66pilzzc+GfW8DQB7X5afhud7pkaM/FEjqzGwwiR
# 0FcPQckvI3th9Kts5UBjCNhY4et6wZm6+gRoSANFZSswggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjBBNTYtRTMyOS00
# RDREMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQAKu0FupjLSv5gYu1RoVVFb9iHupqCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5Jp1OTAiGA8y
# MDIxMDcxNTEyNTAwMVoYDzIwMjEwNzE2MTI1MDAxWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDkmnU5AgEAMAoCAQACAh/aAgH/MAcCAQACAhFKMAoCBQDkm8a5AgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAn348wM4a6nmYJDdTnjyQkUqgrGNn
# 3A//Mz1RBFzh1WSS6euBJxVigEus3HpIhAaHCx1z1N3lKIQh1HBR9w5UZNE/i2cc
# uoYNFU8A94uDYvxHdooQj3OPGOkPVdTXMVOt1y3fcdVZAGg2rBXQwZ5AR0N1M87N
# CCMQ7HxCHCShJCMxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAVt8sLo0ZzfBpwAAAAABWzANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCDxIDyP
# tT+AMIIkdmtesFxw+L0XF/PCNFTIQ75AdME5BjCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIMki4KkoYxGHiUIa5wY8cI0nuOr0xNt7eZDYW1JksIUZMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFbfLC6NGc3wacA
# AAAAAVswIgQgAqCPHXBZkBxXAdAvmpzKZBhbx9jQeHCvxOrMLhFyg/YwDQYJKoZI
# hvcNAQELBQAEggEAWgxWlZJ5HbpHeEsb5+rlM/qIZBHKVFluDXjDqvGRLxHJ7X+o
# 9oX84syeyfbuttQuX8COjie4rcXWtphyAhDzsglc8M3VE22KJPUb6pIgz5nOcEHv
# Erxvf0qqZ041Wri71kalQA0pXe4duyAKEusXmaFwkOPwrsaok/JpD+wRWWzod7P8
# THJLjqVHJV3OFKntT9ugTUELeChJlYOkZDkLLGhOR4mun0npLA9akcV35E5b6Pb5
# vobpFZICpFEDKn2mCxXuBNQY55ULfOegFWKwr24514ueufbfMHWXqARVTQuY60ZY
# p7SiHWFsswgfUKkxNcxVvUjg9QIoDqzLyEfbJw==
# SIG # End signature block
