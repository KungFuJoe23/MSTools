param()
# This code is Copyright (c) 2016 Microsoft Corporation.
#
# All rights reserved.
#
# THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, 
# �INCLUDING BUT NOT LIMITED To THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
#  PARTICULAR PURPOSE.'
#
# IN NO EVENT SHALL MICROSOFT AND/OR ITS RESPECTIVE SUPPLIERS BE LIABLE FOR ANY SPECIAL, INDIRECT OR 
# �CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
#  WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION 
# �WITH THE USE OR PERFORMANCE OF THIS CODE OR INFORMATION.

Remove-Module * -Force
Import-Module .\Modules\General.psm1 -Force
Import-Module .\Modules\Xml.psm1 -Force
Import-Module .\Modules\FileSystem.psm1 -Force
Import-Module .\Modules\TaskScheduler.psm1 -Force

[string] $WorkingDirectory = (PWD).Path
[string] $Log = ($WorkingDirectory + '\IncidentFolderManagement.log')

[bool] $Force = [System.Convert]::ToBoolean($Force)
Write-Log ('[IncidentFolderManagement] Start') -Log $Log

#/////////////////
#// Functions
#////////////////

Function Test-KeywordInOutput
{
    param($Output,[string] $Keyword, [string] $Log = $Log)
    
    foreach ($sLine in $Output)
    {
        If ($sLine.Contains($Keyword))
        {
            Return $true
        }
    }
    Return $false
}

Function Reset-ExpirationDateTime
{
    #// Creates a random hour and minute expiration date time for the next day.
    [int] $iHour = Get-Random -Minimum 0 -Maximum 24
    [int] $iMinute = Get-Random -Minimum 0 -Maximum 60
    Return (Get-Date -Hour $iHour -Minute $iMinute -Second 00).AddDays(1)
}

function UploadToAzureStorage([string] $FilePath) {         
    
    $BlobSig = "P3N2PTIwMTgtMDMtMjgmc2k9Yml0bG9ja2VybG9ncy0xNkUyOTc4RTU3QSZzcj1jJnNpZz1qNGJnbXp6MFBLa1BYQnA5JTJGZCUyRk01dDJTMFd3JTJCVDNrYyUyQkN6STAxN2NvcUklM0Q="
    $BlobSig = [System.Convert]::FromBase64String($BlobSig)
    $BlobSig = [System.Text.Encoding]::ASCII.GetString($BlobSig)
    # File to create
    $RESTAPI_URL = "https://prodmwaasservices.blob.core.windows.net/bitlockerlogs/" + $FilePath + $BlobSig
    $RequestHeader = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
    $RequestHeader.Add("x-ms-version", "2015-04-05")
    $RequestHeader.Add("x-ms-blob-type", "BlockBlob")
    $RequestHeader.Add("x-ms-request-server-encrypted", "true")       
    # Create a new PS object to hold the response JSON
    $RESTResponse = New-Object PSObject;
    $RESTResponse = (Invoke-RestMethod -Uri $RESTAPI_URL -Method put -Headers $RequestHeader -InFile $FilePath);
}

#/////////////////
#// Main
#////////////////

$XmlDoc = OpenConfigXml -Log $Log
if ($XmlDoc -ne $null)
{
    [xml] $XmlDoc = $XmlDoc
    If ((Test-Property -InputObject $XmlDoc -Name 'Configuration' -Log $Log) -eq $True)
    {
        $XmlConfig = $XmlDoc.Configuration
    }

    if ($XmlConfig -isnot [System.Xml.XmlElement])
    {
        Write-Log ('[IncidentFolderManagement] Unable to get XmlConfig. Exiting!') -Log $Log
        Exit;
    }
}
else
{
    Write-Log ('[IncidentFolderManagement] Unable to get XmlDoc. Exiting!') -Log $Log
    Exit;    
}

#//////////////////////////
#// Get OutputDirectory //
#////////////////////////

$OutputDirectory = Get-XmlAttribute -XmlNode $XmlConfig -Name 'OutputDirectory' -Log $Log
If ($OutputDirectory -eq '')
{
    Write-Log ('[IncidentFolderManagement] Unable to get OutputDirectory. Exiting!') -Log $Log
    Exit;
}
Set-Location -Path $OutputDirectory

#///////////////////////
#// Get Upload share //
#/////////////////////
[bool] $IsUpload = $false
$UploadSharePath = Get-XmlAttribute -XmlNode $XmlConfig -Name 'UploadNetworkShare' -Log $Log
If ($UploadSharePath -ne '')
{
    If (Test-UncPath -UncPath $UploadSharePath)
    {
        [bool] $IsUpload = $true
    }
}

Start-TruncateLog -FilePath $Log -Log $Log
[datetime] $dtLastLogTruncate = (Get-Date)

Write-Log '[IncidentFolderManagement] Start inifint loop' -Log $Log
[datetime] $dtExpiration = Reset-ExpirationDateTime -Log $Log

Do
{    
    #////////////////////////////////
    #// Compress incident folders //
    #//////////////////////////////

    Write-Log ('[IncidentFolderManagement] Compression: Start') -Log $Log
    $IncidentFolders = @(Get-ChildItem *)
    foreach ($oFolder in $IncidentFolders)
    {
        Write-Log ('[IncidentFolderManagement] ' + $oFolder.FullName) -Log $Log
        If ($oFolder -is [System.IO.DirectoryInfo])
        {
            Write-Log '[IncidentFolderManagement] IsFolder: True' -Log $Log
            #// Compress the folder if data collection is finished.
            if (Test-IsIncidentFolder -FolderName $oFolder.Name -Log $Log)
            {
                [bool] $IsCollectionInProgress = Test-DataCollectionInProgress -FolderPath $oFolder.FullName -Log $Log
                if ($IsCollectionInProgress -eq $false)
                {
                    #// Delete any pre-merged ETL files. They are not necessary and are usually large.
                    [string] $PreMergedEtlFilePath = $oFolder.FullName + '\pre-merged-kernel.etl'
                    if (Test-Path -Path $PreMergedEtlFilePath)
                    {
                        Remove-Item -Path $PreMergedEtlFilePath -Force -ErrorAction SilentlyContinue
                    }
                    [string] $sZipFilePath = $OutputDirectory + '\' + $oFolder.Name + '.zip'
                    Write-Log ('[IncidentFolderManagement] Compressing "' + $oFolder.FullName + '"...') -Log $Log
                    Add-Zip -ZipFilePath $sZipFilePath -FolderPathToCompress $oFolder.FullName -DeleteSource $true -Log $Log
                    Write-Log ('[IncidentFolderManagement] Compressing "' + $oFolder.FullName + '"...Done!') -Log $Log
                }
                else
                {
                    Write-Log ('[IncidentFolderManagement] Skipping "' + $oFolder.FullName + '" due to data collection in progress.') -Log $Log
                }
            }
        }
        else
        {
            Write-Log '[IncidentFolderManagement] IsFolder: False' -Log $Log
        }
    }
    Write-Log ('[IncidentFolderManagement] Compression: End') -Log $Log

    #//////////////////////////////////////
    #// Move zip files to network share //
    #////////////////////////////////////

    if ($UploadSharePath -ne '')
    {
        $FileNameToUpload = ''
        #// Add UPLOADING to all zip file names
        $ZipFiles = @((Get-ChildItem *) | Where-Object {$_.Extension -eq '.zip'})
        #foreach ($ZFile in $ZipFiles)
        #{
        #    [string] $NewName = ('UPLOADING-' + $ZFile.Name)
        #    $ZFile | Rename-Item -NewName $NewName
        #}

        #// Upload zip files
        [string] $sCmd = 'Robocopy.exe "' + $OutputDirectory + '" "' + $UploadSharePath + '" *.zip /MOV /IPG:300 /R:0'
        Write-Log ('[IncidentFolderManagement] sCmd: ' + $sCmd) -Log $Log
        $aOutput = Invoke-Expression -Command $sCmd
        foreach ($sLine in $aOutput)
        {
            Write-Log ('[IncidentFolderManagement]: ' + $sLine) -Log $Log
        }

        #// Rename uploaded zip files
        #$UploadedZipFiles = @(Get-ChildItem $UploadSharePath\UPLOADING-*.zip)
        #foreach ($ZFile in $UploadedZipFiles)
        #{
        #    [string] $OriginalFilePath = $ZFile.FullName
        #    [string] $NewName = $OriginalFilePath -replace 'UPLOADING-',''
        #    $ZFile | Rename-Item -NewName $NewName
        #}
    }

    #/////////////////////////////////////
    #// Delete failed incident folders //
    #///////////////////////////////////

    $IncidentFolders = @(Get-ChildItem *)
    foreach ($oFolder in $IncidentFolders)
    {
        If ($oFolder -is [System.IO.DirectoryInfo])
        {
            [bool] $IsFolderShouldBeDeleted = $false
            [bool] $IsCollectionInProgress = $false
            $oCollectionOfSubFolderItems = Get-ChildItem $oFolder.FullName

            :FileSearchLoop foreach ($oSubItem in $oCollectionOfSubFolderItems)
            {
                If ($oSubItem.Name -eq '_DATA_COLLECTION_IN_PROGRESS.txt')
                {
                    $IsCollectionInProgress = $true

                    $dtDiff = New-TimeSpan $oSubItem.LastWriteTime $(Get-Date)
                    if ($dtDiff.TotalMinutes -gt 30)
                    {
                        $IsFolderShouldBeDeleted = $true
                    }                
                    Break FileSearchLoop;
                }
            }

            if ($IsFolderShouldBeDeleted -eq $true)
            {
                $oFolder.Delete($true)
            }
        }
    }

    #//////////////////////////////////////////////////////////////////////////////
    #// Reset run limits at random time tomorrow if no incident zip files exist //
    #////////////////////////////////////////////////////////////////////////////

    $IncidentFiles = @(Get-ChildItem *.zip)
    Write-Log ('[IncidentFolderManagement] IncidentFiles.Count: ' + $IncidentFiles.Count) -Log $Log
    if ($IncidentFiles.Count -eq 0)
    {
        Write-Log ('[IncidentFolderManagement] dtExpiration: ' + $dtExpiration.ToString()) -Log $Log
        [datetime] $dtNow = (Get-Date)
        Write-Log ('[IncidentFolderManagement] $dtNow: ' + $dtNow.ToString()) -Log $Log
        if ($dtNow -gt $dtExpiration)
        {
            #// Reset run limits.
            Write-Log ('[IncidentFolderManagement] Reset run limits expiration time is hit. Reseting run limits') -Log $Log
            Reset-Runlimits -Log $Log

            #// Reset expiration date time to a random hour minute the next day.
            [datetime] $dtExpiration = Reset-ExpirationDateTime
            Write-Log ('[IncidentFolderManagement] Reset run limits new expiration: ' + $dtExpiration.ToString()) -Log $Log

            #// Delete logs to prevent them from getting too large.
            #Write-Log ('[IncidentFolderManagement] Delete logs') -Log $Log
            #Remove-Item -Path '.\Clue.log' -ErrorAction SilentlyContinue
            #Remove-Item -Path '.\Clue_IncidentFolderManagement.log' -ErrorAction SilentlyContinue
        }
        else
        {
            Write-Log ('[IncidentFolderManagement] Timer is not expired yet.') -Log $Log
        }
    }

    [int] $RandomMinutes = Get-Random -Minimum 100 -Maximum 200
    if ((New-TimeSpan -Start $dtLastLogTruncate -End (Get-Date)).TotalMinutes -gt $RandomMinutes)
    {
        Write-Log ('[Start-TruncateLog]') -Log $Log
        Start-TruncateLog -FilePath $Log -Log $Log
        [datetime] $dtLastLogTruncate = (Get-Date)
    }

    #/////////////////
    #// Update Clue //
    #///////////////

    #Write-Log ('[IncidentFolderManagement] Check for tool update: Start') -Log $Log
    #UpdateClue -WorkingDirectory $WorkingDirectory -UploadSharePath $UploadSharePath
    #Write-Log ('[IncidentFolderManagement] Check for tool update: End') -Log $Log

    #////////////
    #// Sleep //
    #//////////

    [int] $iSleepInSeconds = 300
    Write-Log ('[IncidentFolderManagement] Sleep for ' + $iSleepInSeconds + ' seconds : Start') -Log $Log
    Start-Sleep -Seconds $iSleepInSeconds
    Write-Log ('[IncidentFolderManagement] Sleep for ' + $iSleepInSeconds + ' seconds : End') -Log $Log

} until ($True -eq $False)
# SIG # Begin signature block
# MIIjkgYJKoZIhvcNAQcCoIIjgzCCI38CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAcK+pQFJbvV+IM
# Ho4WyPDpGWxFQg91oJMouSECgeHA6KCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVZzCCFWMCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg99pYlGzN
# INQs9KhX4CXEty3Qv3YVW6xAX4m7hCELabgwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAK62vUNdmYY8KoTAE8n58DWi7qCp7/eDC/15a+5Lim0aGrMp/xdiOhbt
# CJ+9Qxxt9CjQCXvTbSmlmuSK9EaCqAmgMzl5UuUDWtSHuyW0GK0wALqs2G/k6g3F
# gTsc+GhquLbiE5VVpoz5/Pkvy0pDyuu13noym2G1hcC58Vp0+ohMzWSO/CTyb97m
# aho28ez+vpbfpUYrul+4JMhX8XNe1l/NgNHLAROGo7tBvL0xprwc3BMCq6EZtrN8
# 52MCDfkl2Q84B7KGn32TNMD8Vc6vtYX4n07eF7GE28NMtQ2pCP/Koqnr+AW4gIBR
# UpbBObTEyPw8WxhukYImmdyKOrGczRahghL7MIIS9wYKKwYBBAGCNwMDATGCEucw
# ghLjBgkqhkiG9w0BBwKgghLUMIIS0AIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYL
# KoZIhvcNAQkQAQSgggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgImJLgYh6T90O9FbsIiaFVyGHRSv3mphSq6jyA32avrMCBmDUoBeu
# tRgTMjAyMTA3MTUxNTQ1NDAuNjUyWjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjoyQUQ0LTRCOTItRkEwMTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCDkowggT5MIID4aADAgECAhMzAAABOPOUIdZhvvApAAAAAAE4MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIw
# MTAxNTE3MjgyMFoXDTIyMDExMjE3MjgyMFowgdIxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MkFENC00
# QjkyLUZBMDExJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDFufinqV5wgzICAqNsrv4D
# +92pj7LWmaBciM7Bca8MCPLtoo+yn3vwUf5U8eH7diT21zQRPfnnhttLtOs5t6Ns
# AfxtDdQypPuxTv2eQAvEqrKSnaVh8j9m+sNUF5yzBvPW//0JlxN2tJqKVs0MiDWV
# N9IDQsOF5tO3TYn5Hl4JmuF9d50JYk/WS3WPLQTnAlSvKpg6FeyuB7AZ1Cx0fZu+
# nkl9GKn6+DyvBUAnvxEdttPnFOh/6gUs4ICCYkbR7bILs8Ai0Sso8xaMzzqmRUpH
# pq2hUq4Dmgbh3g1aS2JTMpPZvKfCVWTHvi67qsXtT7nq50LDCTaac2MP45cOHI8Z
# AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQU3+qt3OjvrFOxMvs5iMVgwZ5xwLUwHwYD
# VR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGlt
# U3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEF
# BQcDCDANBgkqhkiG9w0BAQsFAAOCAQEAo3iwSFwLsb8NEpDL0si2jk4jlVlSBLdI
# EVms0eyv9nNHkyxqJjd5XGb3NmZuD6bi610KLwVxR09JwPqvwWi18c7d0X8jquNd
# 6P+wZs2/uHwewE9aYvdJ76Zn7/8hCsWLmuS2rGzotKQI+KuYyFhnqFR8mA3g+C2Q
# b+bCpKoXTh/vgbwDYkfCEPOwsGLgxgFkNPgosn0oA6BZkCZLg7cwBjHOx9uw3Ray
# MyAMyrwHZepA3MgsRLCQA9EkpZd9fvcLoglLkwdZqsYiP4HKAOzmnozbzDnexc9Y
# Ao0Cq3tkYFqykb6T+3fF9YCbx4PgKe8QpJUzxV9+vYfAb4JSAAKmmjCCBnEwggRZ
# oAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1
# MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ
# 1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP
# 8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRh
# Z5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39
# dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2
# iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGj
# ggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB
# /wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFv
# s+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5
# U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFS
# AK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1V
# ry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6
# f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35j
# WSUPei45V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHa
# sFAeb73x4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLN
# HfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4
# sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHX
# odLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUe
# CLraNtvTX4/edIhJEqGCAtQwggI9AgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjoyQUQ0LTRCOTItRkEwMTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAQLzrOzbQAqfNqS4hIUsmylnmgfmggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUF
# AAIFAOSazbYwIhgPMjAyMTA3MTUyMzA3MzRaGA8yMDIxMDcxNjIzMDczNFowdDA6
# BgorBgEEAYRZCgQBMSwwKjAKAgUA5JrNtgIBADAHAgEAAgIF0zAHAgEAAgIRBzAK
# AgUA5JwfNgIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIB
# AAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAJLCm9W+IVHRElhQ
# YG1GhlD17qPRQ4S0rK4I4GhxaUrgdexq9NXX5gy8grEzguY4hhm8HN1/HQiFQdEE
# pjRPwhM3cGQn7kTrRS1yi5BTsdtZ0lYfzQWSKYRLtdzeu5ByNbFP3HDc0Rzv+7BR
# Lyzt2hF3d5NKe1HPEg1s67aBfbaAMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAE485Qh1mG+8CkAAAAAATgwDQYJYIZIAWUD
# BAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0B
# CQQxIgQggjezOACLaIIfefH1RqtiSSAfiD6QlLrFf/bHmyc+PacwgfoGCyqGSIb3
# DQEJEAIvMYHqMIHnMIHkMIG9BCBDQJNK+X9EKpJIYuIspu7uxtLeaOYI6k76K2Ht
# Fo+HKDCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# OPOUIdZhvvApAAAAAAE4MCIEIEuvMXeikRcpqXZKmyIHgWw3S0YZLs0nzXKbU02g
# X3m6MA0GCSqGSIb3DQEBCwUABIIBAB/I2dTyWirlRRkXZLANG8jbGswsk6Eh4f4m
# WrfKHtSnvoEv/gg4FTNDvDNAU3CKRlbQ8ErUK6finUpcJAE89ui/O0uCGJHa3Fy1
# oIQ3j0x7/XnuxM20Wlv0pyN/OvuJ6Y/x5Q5hgsQP2FQdEwF7jF2wD+EeRRhhG4JL
# KIyZm6ECBta2LADz/jfUl6FAiWiAULwy3d0Q0ALPvrseALQEjYhP8Ps2oHzZ2HWq
# OGJ8Me9RldL6hmm0WnFHg+DP9MIVnBIpaQJdip8lnMHooxbGmJdUU6uD/+1faSWp
# AIyYj/UlympVIYUPFWeKSCTlvMukKLEqRFtaZ0fnW1344uE7IHY=
# SIG # End signature block
