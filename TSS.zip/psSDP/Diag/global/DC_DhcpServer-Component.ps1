﻿#************************************************
# DC_DhcpServer-Component.ps1
# Version x
# Date: 2009-2014
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about DHCP Server.
# Called from: Networking Diags
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSDHCPServer -Status $ScriptVariable.ID_CTSDHCPServerDescription

function RunNetSH ([string]$NetSHCommandToExecute="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSDHCPServer -Status "netsh $NetSHCommandToExecute"
	
	$NetSHCommandToExecuteLength = $NetSHCommandToExecute.Length + 6
	"-" * ($NetSHCommandToExecuteLength) + "`r`n" + "netsh $NetSHCommandToExecute" + "`r`n" + "-" * ($NetSHCommandToExecuteLength) | Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
}


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append	
}


$sectionDescription = "DHCP Server"

# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber


#----------W8/WS2012 powershell cmdlets
$outputFile= $Computername + "_DhcpServer_info_pscmdlets.TXT"
"===================================================="	| Out-File -FilePath $OutputFile -append
"DHCP Server Powershell Cmdlets"						| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"Overview"												| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"DHCP Server Settings"									| Out-File -FilePath $OutputFile -append
"   1. Get-DhcpServerAuditLog"							| Out-File -FilePath $OutputFile -append
"   2. Get-DhcpServerDatabase"							| Out-File -FilePath $OutputFile -append
"   3. Get-DhcpServerDnsCredential"						| Out-File -FilePath $OutputFile -append
"   4. Get-DhcpServerInDC"								| Out-File -FilePath $OutputFile -append
"   5. Get-DhcpServerSetting"							| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"DHCP Server v4"										| Out-File -FilePath $OutputFile -append
"   1. Get-DhcpServerv4Binding"							| Out-File -FilePath $OutputFile -append
"   2. Get-DhcpServerv4Class"							| Out-File -FilePath $OutputFile -append
"   3. Get-DhcpServerv4DnsSetting"						| Out-File -FilePath $OutputFile -append
"   4. Get-DhcpServerv4ExclusionRange"					| Out-File -FilePath $OutputFile -append
"   5. Get-DhcpServerv4Failover"						| Out-File -FilePath $OutputFile -append
"   6. Get-DhcpServerv4Filter"							| Out-File -FilePath $OutputFile -append
"   7. Get-DhcpServerv4FilterList"						| Out-File -FilePath $OutputFile -append
"   8. Get-DhcpServerv4MulticastExclusionRange"			| Out-File -FilePath $OutputFile -append
"   9. Get-DhcpServerv4MulticastScope"					| Out-File -FilePath $OutputFile -append
"  10. Get-DhcpServerv4MulticastScopeStatististics"		| Out-File -FilePath $OutputFile -append
"  11. Get-DhcpServerv4OptionDefinition"				| Out-File -FilePath $OutputFile -append
"  12. Get-DhcpServerv4OptionValue"						| Out-File -FilePath $OutputFile -append
"  13. Get-DhcpServerv4Policy"							| Out-File -FilePath $OutputFile -append
"  14. Get-DhcpServerv4Scope"							| Out-File -FilePath $OutputFile -append
"  15. Get-DhcpServerv4ScopeStatistics"					| Out-File -FilePath $OutputFile -append
"  16. Get-DhcpServerv4Statistics"						| Out-File -FilePath $OutputFile -append
"  17. Get-DhcpServerv4Superscope"						| Out-File -FilePath $OutputFile -append
"  18. Get-DhcpServerv4SuperscopeStatistics"			| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"DHCP Server v6"										| Out-File -FilePath $OutputFile -append
"   1. Get-DhcpServerv6Binding"							| Out-File -FilePath $OutputFile -append
"   2. Get-DhcpServerv6Class"							| Out-File -FilePath $OutputFile -append
"   3. Get-DhcpServerv6DnsSetting"						| Out-File -FilePath $OutputFile -append
"   4. Get-DhcpServerv6ExclusionRange"					| Out-File -FilePath $OutputFile -append
"   5. Get-DhcpServerv6OptionDefinition"				| Out-File -FilePath $OutputFile -append
"   6. Get-DhcpServerv6OptionValue"						| Out-File -FilePath $OutputFile -append
"   7. Get-DhcpServerv6Scope"							| Out-File -FilePath $OutputFile -append
"   8. Get-DhcpServerv6ScopeStatistics"					| Out-File -FilePath $OutputFile -append
"   9. Get-DhcpServerv6StatelessStatistics"				| Out-File -FilePath $OutputFile -append
"  10. Get-DhcpServerv6StatelessStore"					| Out-File -FilePath $OutputFile -append
"  11.Get-DhcpServerv6Statistics"						| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"DHCP Server Version"									| Out-File -FilePath $OutputFile -append
"   1. Get-DhcpServerVersion"							| Out-File -FilePath $OutputFile -append
"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
"DHCP Server Failover Statistics"						| Out-File -FilePath $OutputFile -append
"   1. DHCP Server Failover Statistics Per Scope"								| Out-File -FilePath $OutputFile -append
"       (using Get-DhcpServer4Failover and Get-DhcpServerv4ScopeStatistics)"	| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append



$dhcpServerCheck = Test-path "HKLM:\SYSTEM\CurrentControlSet\Services\DHCPserver"
if ($dhcpServerCheck)
{
	if ((Get-Service "DHCPserver").Status -eq 'Running')
	{
		if ($bn -ge 9200)
		{
			# The powershell cmdlets that have been removed by comment because they require input
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"DHCP Server Settings"									| Out-File -FilePath $OutputFile -append
			"===================================================="	| Out-File -FilePath $OutputFile -append
			RunPS "Get-DhcpServerAuditLog" 							# W8/WS2012, W8.1/WS2012R2	#fl
			RunPS "Get-DhcpServerDatabase" 							# W8/WS2012, W8.1/WS2012R2	#fl
			RunPS "Get-DhcpServerDnsCredential" 				-ft # W8/WS2012, W8.1/WS2012R2	#ft
			RunPS "Get-DhcpServerInDC" 							-ft	# W8/WS2012, W8.1/WS2012R2	#ft
			RunPS "Get-DhcpServerSetting" 							# W8/WS2012, W8.1/WS2012R2	#fl
			"`n"	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"DHCP Server v4"										| Out-File -FilePath $OutputFile -append
			"===================================================="	| Out-File -FilePath $OutputFile -append
			RunPS "Get-DhcpServerv4Binding" 					-ft	# W8/WS2012, W8.1/WS2012R2	#ft
			RunPS "Get-DhcpServerv4Class" 						-ft	# W8/WS2012, W8.1/WS2012R2	#ft
			RunPS "Get-DhcpServerv4DnsSetting" 						# W8/WS2012, W8.1/WS2012R2	#fl
			RunPS "Get-DhcpServerv4ExclusionRange" 				-ft	# W8/WS2012, W8.1/WS2012R2	#ft
			RunPS "Get-DhcpServerv4Failover" 						# W8/WS2012, W8.1/WS2012R2	#unknown
			RunPS "Get-DhcpServerv4Filter" 							# W8/WS2012, W8.1/WS2012R2	#unknown
			RunPS "Get-DhcpServerv4FilterList" 					-ft	# W8/WS2012, W8.1/WS2012R2	#ft
			#RunPS "Get-DhcpServerv4FreeIPAddress" 					# W8/WS2012, W8.1/WS2012R2	
			#RunPS "Get-DhcpServerv4Lease" 							# W8/WS2012, W8.1/WS2012R2	
			RunPS "Get-DhcpServerv4MulticastExclusionRange"			# W8/WS2012, W8.1/WS2012R2	#unknown
			#RunPS "Get-DhcpServerv4MulticastLease" 				# W8/WS2012, W8.1/WS2012R2	
			RunPS "Get-DhcpServerv4MulticastScope" 					# W8/WS2012, W8.1/WS2012R2	#unknown
			RunPS "Get-DhcpServerv4MulticastScopeStatistics" 		# W8/WS2012, W8.1/WS2012R2	#unknown
			RunPS "Get-DhcpServerv4OptionDefinition" 			-ft	# W8/WS2012, W8.1/WS2012R2	#ft
			RunPS "Get-DhcpServerv4OptionValue" 					# W8/WS2012, W8.1/WS2012R2	#unknown
			RunPS "Get-DhcpServerv4Policy" 							# W8/WS2012, W8.1/WS2012R2	#unknown
			#RunPS "Get-DhcpServerv4PolicyIPRange" 					# W8/WS2012, W8.1/WS2012R2	
			#RunPS "Get-DhcpServerv4Reservation" 					# W8/WS2012, W8.1/WS2012R2	
			RunPS "Get-DhcpServerv4Scope" 						-ft	# W8/WS2012, W8.1/WS2012R2	#ft
			RunPS "Get-DhcpServerv4ScopeStatistics" 			-ft	# W8/WS2012, W8.1/WS2012R2	#ft
			RunPS "Get-DhcpServerv4Statistics" 						# W8/WS2012, W8.1/WS2012R2	#fl
			RunPS "Get-DhcpServerv4Superscope" 						# W8/WS2012, W8.1/WS2012R2	#fl
			RunPS "Get-DhcpServerv4SuperscopeStatistics" 			# W8/WS2012, W8.1/WS2012R2	#unknown
			"`n"	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"DHCP Server v6"										| Out-File -FilePath $OutputFile -append
			"===================================================="	| Out-File -FilePath $OutputFile -append
			RunPS "Get-DhcpServerv6Binding" 						# W8/WS2012, W8.1/WS2012R2	#unknown	
			RunPS "Get-DhcpServerv6Class" 						-ft	# W8/WS2012, W8.1/WS2012R2	#ft
			RunPS "Get-DhcpServerv6DnsSetting" 						# W8/WS2012, W8.1/WS2012R2	#fl
			RunPS "Get-DhcpServerv6ExclusionRange" 					# W8/WS2012, W8.1/WS2012R2	#unknown
			#RunPS "Get-DhcpServerv6FreeIPAddress"					# W8/WS2012, W8.1/WS2012R2	
			#RunPS "Get-DhcpServerv6Lease" 							# W8/WS2012, W8.1/WS2012R2	
			RunPS "Get-DhcpServerv6OptionDefinition" 			-ft	# W8/WS2012, W8.1/WS2012R2	#ft
			RunPS "Get-DhcpServerv6OptionValue" 					# W8/WS2012, W8.1/WS2012R2	#unknown
			#RunPS "Get-DhcpServerv6Reservation" 					# W8/WS2012, W8.1/WS2012R2	
			RunPS "Get-DhcpServerv6Scope" 							# W8/WS2012, W8.1/WS2012R2	#unknown
			RunPS "Get-DhcpServerv6ScopeStatistics" 				# W8/WS2012, W8.1/WS2012R2	#unknown
			RunPS "Get-DhcpServerv6StatelessStatistics" 			# W8/WS2012, W8.1/WS2012R2	#unknown
			RunPS "Get-DhcpServerv6StatelessStore" 				-ft	# W8/WS2012, W8.1/WS2012R2	#ft
			RunPS "Get-DhcpServerv6Statistics"						# W8/WS2012, W8.1/WS2012R2	#fl
			"`n"	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"DHCP Server Version"									| Out-File -FilePath $OutputFile -append
			"===================================================="	| Out-File -FilePath $OutputFile -append
			RunPS "Get-DhcpServerVersion" 							# W8/WS2012, W8.1/WS2012R2	#fl
			"`n"	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"DHCP Server Failover Statistics"						| Out-File -FilePath $OutputFile -append
			"===================================================="	| Out-File -FilePath $OutputFile -append
			"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
			"DHCP Server Failover Statistics Per Scope"				| Out-File -FilePath $OutputFile -append
			"  (using Get-DhcpServer4Failover and Get-DhcpServerv4ScopeStatistics)"	| Out-File -FilePath $OutputFile -append
			"----------------------------------------------------"	| Out-File -FilePath $OutputFile -append
			$dhcpSrvFailoverScopes = Get-DhcpServerv4Failover
			foreach ($scope in $dhcpSrvFailoverScopes)
			{
				$scopeId = $scope.ScopeId
				Get-DhcpServerv4ScopeStatistics -ScopeId $scopeId | fl	| Out-File -FilePath $OutputFile -append
			}
			"`n"	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
			"`n"	| Out-File -FilePath $OutputFile -append
		}
		else
		{
			"This server is not running WS2012 or WS2012 R2. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
		}
	}
	else
	{ "The `"DHCP Server`" service is not Running. Not running pscmdlets." 	| Out-File -FilePath $OutputFile -append }
}
else
{ "The `"DHCP Server`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append }
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append

CollectFiles -filesToCollect $OutputFile -fileDescription "DHCP Server Information (Powershell)" -SectionDescription $sectionDescription





$OutputFile = $ComputerName + "_DhcpServer_netsh_info.TXT"
"===================================================="	| Out-File -FilePath $OutputFile -append
"DHCP Server Netsh Output"								| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"Overview"												| Out-File -FilePath $OutputFile -append
"----------------------------------------"				| Out-File -FilePath $OutputFile -append
"   1. netsh dhcp show server"							| Out-File -FilePath $OutputFile -append
"   2. netsh dhcp server show all"						| Out-File -FilePath $OutputFile -append
"   3. netsh dhcp server show version"					| Out-File -FilePath $OutputFile -append
"   4. netsh dhcp server show auditlog"					| Out-File -FilePath $OutputFile -append
"   5. netsh dhcp server show dbproperties"				| Out-File -FilePath $OutputFile -append
"   6. netsh dhcp server show bindings"					| Out-File -FilePath $OutputFile -append
"   7. netsh dhcp server show detectconflictretry"		| Out-File -FilePath $OutputFile -append
"   8. netsh dhcp server show server"					| Out-File -FilePath $OutputFile -append
"   9. netsh dhcp server show serverstatus"				| Out-File -FilePath $OutputFile -append
"  10. netsh dhcp server show scope"					| Out-File -FilePath $OutputFile -append
"  11. netsh dhcp server show superscope"				| Out-File -FilePath $OutputFile -append
"  12. netsh dhcp server show class"					| Out-File -FilePath $OutputFile -append
"  13. netsh dhcp server show dnsconfig"				| Out-File -FilePath $OutputFile -append
"  14. netsh dhcp server show dnscredentials"			| Out-File -FilePath $OutputFile -append
"  15. netsh dhcp server show mibinfo"					| Out-File -FilePath $OutputFile -append
"  16. netsh dhcp server show mscope"					| Out-File -FilePath $OutputFile -append
"  17. netsh dhcp server show optionvalue"				| Out-File -FilePath $OutputFile -append
"  18. netsh dhcp server show scope"					| Out-File -FilePath $OutputFile -append
"  19. netsh dhcp server show superscope"				| Out-File -FilePath $OutputFile -append
"  20. netsh dhcp server show userclass"				| Out-File -FilePath $OutputFile -append
"  21. netsh dhcp server show vendorclass"				| Out-File -FilePath $OutputFile -append
"  22. netsh dhcp server show optiondef"				| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append


$dhcpServerCheck = Test-path "HKLM:\SYSTEM\CurrentControlSet\Services\DHCPserver"
if ($dhcpServerCheck)
{
	if ((Get-Service "DHCPserver").Status -eq 'Running')
	{
		#----------Netsh for DHCP Server
		RunNetSH -NetSHCommandToExecute "dhcp show server"
		RunNetSH -NetSHCommandToExecute "dhcp server show all"
		RunNetSH -NetSHCommandToExecute "dhcp server show version"
		RunNetSH -NetSHCommandToExecute "dhcp server show auditlog"
		RunNetSH -NetSHCommandToExecute "dhcp server show dbproperties"
		RunNetSH -NetSHCommandToExecute "dhcp server show bindings"
		RunNetSH -NetSHCommandToExecute "dhcp server show detectconflictretry"
		RunNetSH -NetSHCommandToExecute "dhcp server show server"
		RunNetSH -NetSHCommandToExecute "dhcp server show serverstatus"
		RunNetSH -NetSHCommandToExecute "dhcp server show scope"
		RunNetSH -NetSHCommandToExecute "dhcp server show superscope"
		RunNetSH -NetSHCommandToExecute "dhcp server show class"
		RunNetSH -NetSHCommandToExecute "dhcp server show dnsconfig"
		RunNetSH -NetSHCommandToExecute "dhcp server show dnscredentials"
		RunNetSH -NetSHCommandToExecute "dhcp server show mibinfo"
		RunNetSH -NetSHCommandToExecute "dhcp server show mscope"
		RunNetSH -NetSHCommandToExecute "dhcp server show optionvalue"
		RunNetSH -NetSHCommandToExecute "dhcp server show scope"
		RunNetSH -NetSHCommandToExecute "dhcp server show superscope"
		RunNetSH -NetSHCommandToExecute "dhcp server show userclass"
		RunNetSH -NetSHCommandToExecute "dhcp server show vendorclass"
		RunNetSH -NetSHCommandToExecute "dhcp server show optiondef"

		#-----DHCP Server Dump
		$filesToCollect = $ComputerName + "_DhcpServer_netsh_dump.TXT"
		$commandToRun = "netsh dhcp server dump > " +  $filesToCollect
		RunCMD -CommandToRun $commandToRun -filesToCollect $filesToCollect -fileDescription "DHCP Server Netsh Dump" -sectionDescription $sectionDescription 
	}
	else
	{
		"The DHCP Server service is not Running. Not running netsh commands." 	| Out-File -FilePath $OutputFile -append
		"The DHCP Server service is not Running. Not running netsh commands." 	| Out-File -FilePath $filesToCollect -append
	}
}
else
{
	"The `"DHCP Server`" service does not exist. Not running netsh commands."	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
}

CollectFiles -sectionDescription $sectionDescription -fileDescription "DHCP Server Netsh Output" -filesToCollect $filesToCollect
CollectFiles -sectionDescription $sectionDescription -fileDescription "DHCP Server Netsh Dump" -filesToCollect $OutputFile



#----------DHCP Server registry output
$SvcKey = "HKLM:\SYSTEM\CurrentControlSet\services\DHCPServer"
if (Test-Path $SvcKey) 
{
	#----------Registry
	$OutputFile= $Computername + "_DhcpServer_reg_.TXT"
	$CurrentVersionKeys = "HKLM\SYSTEM\CurrentControlSet\Services\DHCPServer"
	$sectionDescription = "DHCP Server"
	RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -OutputFile $OutputFile -fileDescription "DhcpServer Registry Keys" -SectionDescription $sectionDescription
}


#----------DHCP Server BPA
	# This runs in the TS_Main.ps1 script.


#----------CDHCP Server event logs for WS2008+
if ($OSVersion.Build -gt 6000)
{
	$sectionDescription = "DHCP Server EventLog"
	
	#----------Dhcp-Server EventLog / Operational
	$EventLogNames = "Microsoft-Windows-Dhcp-Server/Operational"
	$Prefix = ""
	$Suffix = "_evt_"
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
	
	#----------Dhcp-Server EventLog /Admin
	#_# $EventLogNames = "Microsoft-Windows-Dhcp-Server/Admin"
	$EventLogNames = "DhcpAdminEvents", "Microsoft-Windows-Dhcp-Server/FilterNotifications"
	$Prefix = ""
	$Suffix = "_evt_"
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
}

# SIG # Begin signature block
# MIIjfAYJKoZIhvcNAQcCoIIjbTCCI2kCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCPUFQFjM4WeW6B
# qNSU434w7lwvltxdO6cqDV+SQ2ZEFKCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVUTCCFU0CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgBZW6gOAb
# Ila/h/WYUiqtwFt/KfwRU2AEpbu2ysdHipUwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAKs+sGHZHxRxLj67XUJEI4yhni6EGYi5p3TjS7W6SHBtFlBBzV7V40Ms
# HdxjdpW2RZF5YAkn9cC+mZpY0MO1HVf/x1SIycgsMxDkmqfH8AsIyvB91ruW2bAv
# 82CuT7BO0X2EhoglgaaNe/OFQ60Gn/5tiwvHd37bvWIsIrxDk3qjmqR85KPWnpu7
# na6vRXYON1GR2oYkHFJU6jRHZiyAZSiUzzgWZsdoAqbTH5UOL9rNDXPZEnQIVoLF
# vCCnNUA1x1gigtSUOTeQaa+dfcvMjXAnRSTRhZlyuM3zSrmEn7qeY015p/P+POCf
# gSFsacsmjVEqEdgVo0yowGKdwLHRJhqhghLlMIIS4QYKKwYBBAGCNwMDATGCEtEw
# ghLNBgkqhkiG9w0BBwKgghK+MIISugIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYL
# KoZIhvcNAQkQAQSgggFABIIBPDCCATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgR7WACTrdL4uA1c0J6WxrRjaehc6ISKwpqZ0cvWntL4wCBmCJ1nt4
# VBgTMjAyMTA1MTkyMjIzNTcuMTExWjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFt
# ZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046N0JGMS1F
# M0VBLUI4MDgxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# gg48MIIE8TCCA9mgAwIBAgITMwAAAVHDUOdZbKrGpwAAAAABUTANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMDExMTIxODI2
# MDRaFw0yMjAyMTExODI2MDRaMIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo3QkYxLUUzRUEtQjgwODElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ/Sh++qhK477ziJI1mx6bTJGA45hviRJs4Lsq/1cY2Y
# Gf4oPDJOO46kiT+UcR/7A8qoWLu4z0jvOrImYfLuwwV/S/CPgAfvHzz7w+LqCyg9
# tgaaBZeAfBcOSu0rom728Rje2nS9f81vrFl5Vb6Q4RDyCgyArxHTYxky4ZLX37Y3
# n4PZbpgTFASdhuP4OGndHQ70TZiojGV13vy5eEIP6D0s1wlBGKEkqmuQ/uTEYplX
# uf2Ey49I1a/IheOVdIU+1R/DiTuGCJnJ2Yaug8NRvsOgAkRnjxZjlqlvLRGdd0jJ
# jqria05MMsvM8jbVbbSQF+3YhS20dErzJWyWVitCh3cCAwEAAaOCARswggEXMB0G
# A1UdDgQWBBTFd//jaFBikzRoOjjMhOnzdUTqbTAfBgNVHSMEGDAWgBTVYzpcijGQ
# 80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNy
# dDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# CwUAA4IBAQAr/fXAFYOZ8dEqo7y30M5roDI+XCfTROtHbkh9S6cR2IpvS7N1H4mH
# e7dCb8hMP60UxCh2851eixS5V/vpRyTBis2Zx7U3tjiOmRxZzYhYbYMlrmAya5uy
# kMpDYtRtS27lYnvTHoZqCvoQYmZ563H2UpwUqJK7ztkBFhwtcZ2ecDPNlBI6axWD
# pHIVPukXKAo45iBRn4EszY9TCG3+JXCeRaFdTIOhcBeOQoozlx1V685IrDGfabg6
# RY4xFekwGOiDYDJIS3r/wFaMNLBfDH0M7SSJRWHRRJGeTRfyMs6AtmG/YsOGwinQ
# a3Q9wLOpr6BkjYwgupTnc+hHqyStzYRYMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAA
# AjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0
# aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEP
# ADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPl
# YcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2T
# rNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFh
# E24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+c
# Bj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn
# 9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQB
# gjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEE
# AYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB
# /zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEug
# SaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsG
# AQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jv
# b0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEE
# AYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9Q
# S0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcA
# YQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZI
# hvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20Z
# MLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX
# /1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+TH
# zvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnx
# zplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjY
# lPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kW
# umGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3
# ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slva
# yA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5
# KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czm
# TfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYIC
# zjCCAjcCAQEwgfihgdCkgc0wgcoxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjdCRjEtRTNFQS1CODA4MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQCg
# oq9z8T+kQgslTCUgFaDFetcjXqCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5FADyzAiGA8yMDIxMDUyMDA1Mzgx
# OVoYDzIwMjEwNTIxMDUzODE5WjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDkUAPL
# AgEAMAoCAQACAhkVAgH/MAcCAQACAhFVMAoCBQDkUVVLAgEAMDYGCisGAQQBhFkK
# BAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJ
# KoZIhvcNAQEFBQADgYEAqk9uNflrwqOMR91pqaK5YS+20j2ZqAr343jcYYMTjaiV
# t9AL4BD4Hu2zpaj4oIYavwyQh2usAaRU8THj4ncLUxHGdYr1OG2f/VmcqcwJVr4i
# ysmAWBEo2miC/4rGquA3WPRddZCclbmpEHUnAMwhTHZv6WodDEMC9Op5c3uVjGIx
# ggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAA
# AVHDUOdZbKrGpwAAAAABUTANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkD
# MQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCDB+O54bdTOI66kasWzFuSK
# QVOUlU/ll/9nGKgNNU+yyDCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIC7N
# XJmI+NbBWQcAphb7/UnD+bbrlIcbL/7dAfVxeuVBMIGYMIGApH4wfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFRw1DnWWyqxqcAAAAAAVEwIgQgXh3x
# EtLo7ZLQMxY+WmSph22uhPsBj8WTjk5JOpzZdUkwDQYJKoZIhvcNAQELBQAEggEA
# n0uYArcXnGQXIa9nC9kuPOeuw22xY6IpIAmHSMAvqVuXvlbzPnQ+gTt3sGXa3Yl6
# Pa0rs7OTr/XES9tocJc9Tfo08Uwta5EDT1mrqMjg5hqPREzpdXxYNR5rU681Dmxp
# h4Mck+CAvGxTRmTK3Z0HP6vo7Wr7x1Kemzp8YYKK53LKvbME9SivDFlHmTLi3EHk
# lN6NnIyM5qUryOveIRGENWW7KwTPrV/pxfMbT68MarWrXTrG1m+GC4hBx8iVq1la
# Yvp94sTZLNfU1ck/4axoY+8KWZS8baDrCXAXg7x9l6CAlpN/2wtGKD85hAGw6iJy
# osNdyLhGN+EnISlv+xEeVg==
# SIG # End signature block
