﻿#************************************************
# DC_DnsDhcpDynamicUpdates.ps1
# Version 1.0
# Date: 2014
# Author: Boyd Benson (bbenson@microsoft.com); Joel Christiansen (joelch@microsoft.com)
# Description: Collects information about DNS and DHCP Dynamic Updates.
# Called from: Networking Diags
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSDHCPServer -Status $ScriptVariable.ID_CTSDHCPServerDescription

function RunNetSH ([string]$NetSHCommandToExecute="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSDHCPServer -Status "netsh $NetSHCommandToExecute"
	
	$NetSHCommandToExecuteLength = $NetSHCommandToExecute.Length + 6
	"-" * ($NetSHCommandToExecuteLength) + "`r`n" + "netsh $NetSHCommandToExecute" + "`r`n" + "-" * ($NetSHCommandToExecuteLength) | Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
}


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append	
}


$sectionDescription = "Dynamic DNS Updates (Server side)"


#----------W8/WS2012 powershell cmdlets
# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

$outputFile= $Computername + "_DnsDhcpDynamicUpdates_info.TXT"

"========================================"	| Out-File -FilePath $OutputFile -append
"Dynamic DNS Update Troubleshooting"		| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append
"Questions:"	| Out-File -FilePath $OutputFile -append
"[1] Q: What configuration settings does the DHCP Server have for DNS Registrations?"	| Out-File -FilePath $OutputFile -append
"      A: Review the section `"DHCP Server DNS Settings`""	| Out-File -FilePath $OutputFile -append
"  "	| Out-File -FilePath $OutputFile -append
"[2] Q: Is the DHCP Server configured for DNS Credentials?"	| Out-File -FilePath $OutputFile -append
"      A: Review the section named `"DHCP Server DNS Credentials`""	| Out-File -FilePath $OutputFile -append
"  "	| Out-File -FilePath $OutputFile -append
"[3] Q: What accounts are members of the DnsUpdateProxy group?"	| Out-File -FilePath $OutputFile -append
"      A: Review the section named `"DnsUpdateProxy Group Members`""	| Out-File -FilePath $OutputFile -append
"  "	| Out-File -FilePath $OutputFile -append
"[4] Q: How is the DHCP Server configured for the registry values DynamicDNSQueueLength and DatabaseCleanupInterval?"	| Out-File -FilePath $OutputFile -append
"      A: Review the section named `"DHCP Server registry values`""	| Out-File -FilePath $OutputFile -append
"  "	| Out-File -FilePath $OutputFile -append
"[5] Q: What DNS Reverse Lookup Zones exist?"	| Out-File -FilePath $OutputFile -append
"      A: Review the section named `"DNS Reverse Lookup Zones`""	| Out-File -FilePath $OutputFile -append
"  "	| Out-File -FilePath $OutputFile -append
"[6] Q: What access does the permissions entry for `"Authenticated Users`" have on each Active Directory Integrated Zone"	| Out-File -FilePath $OutputFile -append
"    A: Review the section named `"DNS Permissions for `"Authenticated Users`" on each Active Directory Integrated Zone`""	| Out-File -FilePath $OutputFile -append
"  "	| Out-File -FilePath $OutputFile -append
"[7] Q: What are the DHCP Server DNS Settings on all the Scopes?"	| Out-File -FilePath $OutputFile -append
"    A: Review the section named `"DHCP Scope DNS Settings`""	| Out-File -FilePath $OutputFile -append
"  "	| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append


"========================================"	| Out-File -FilePath $OutputFile -append
"[1] DHCP Server DNS Settings" 	| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append

$dhcpServerServiceStatus = get-service * | where {$_.name -eq "DHCPserver"}	
if ($dhcpServerServiceStatus -ne $null)
{
	if ((Get-Service "DHCPserver").Status -eq 'Running')
	{		
		if ($bn -ge 9200)
		{
			RunPS "Get-DhcpServerv4DnsSetting" 						# W8/WS2012, W8.1/WS2012R2	#fl
			"`n"	| Out-File -FilePath $OutputFile -append

			$DhcpServerv4DnsSettings = Get-DhcpServerv4DnsSetting
			"====================" 	| Out-File -FilePath $OutputFile -append
			"Representation of the User Interface with Current Settings"	| Out-File -FilePath $OutputFile -append
			"====================" 	| Out-File -FilePath $OutputFile -append

			"---------------------------------------------------------------------------"	| Out-File -FilePath $OutputFile -append
			"                        IPv4 Properties"	| Out-File -FilePath $OutputFile -append
			"---------------------------------------------------------------------------"	| Out-File -FilePath $OutputFile -append
			"           DNS tab"	| Out-File -FilePath $OutputFile -append
			"---------------------------------------------------------------------------"	| Out-File -FilePath $OutputFile -append
			"  You can setup the DHCP server to automatically update authoritative DNS" | Out-File -FilePath $OutputFile -append
			"  servers with the host (A) and pointer (PTR) records of DHCP clients." | Out-File -FilePath $OutputFile -append
			
			if ($DhcpServerv4DnsSettings.DynamicUpdates -eq "OnClientRequest")
			{
				"  [X] Enable DNS Dynamic updates according to the settings below:"	| Out-File -FilePath $OutputFile -append
				"     [X] Dynamically update DNS records only if requested by the DHCP"	| Out-File -FilePath $OutputFile -append
				"         clients"	| Out-File -FilePath $OutputFile -append
				"     [ ] Always dynamically update DNS records"	| Out-File -FilePath $OutputFile -append
			}
			elseif ($DhcpServerv4DnsSettings.DynamicUpdates -eq "Always")
			{
				"  [X] Enable DNS Dynamic updates according to the settings below:"	| Out-File -FilePath $OutputFile -append
				"     [ ] Dynamically update DNS records only if requested by the DHCP"	| Out-File -FilePath $OutputFile -append
				"         clients"	| Out-File -FilePath $OutputFile -append
				"     [X] Always dynamically update DNS records"	| Out-File -FilePath $OutputFile -append
			}
			if ($DhcpServerv4DnsSettings.DeleteDnsRROnLeaseExpiry -eq $true)
			{
				"  [X] Discard A and PTR records when lease is deleted"	| Out-File -FilePath $OutputFile -append
			}
			else
			{
				"  [ ] Discard A and PTR records when lease is deleted"	| Out-File -FilePath $OutputFile -append
			}
			if ($DhcpServerv4DnsSettings.UpdateDnsRRForOlderClients -eq $false)	
			{
				"  [ ] Dynamically update DNS records for DHCP clients that do not request"	| Out-File -FilePath $OutputFile -append
				"      updates (for example, clients running NT 4.0)"	| Out-File -FilePath $OutputFile -append
			}
			else
			{
				"  [X] Dynamically update DNS records for DHCP clients that do not request"	| Out-File -FilePath $OutputFile -append
				"      updates (for example, clients running NT 4.0)"	| Out-File -FilePath $OutputFile -append
			}
			if ($DhcpServerv4DnsSettings.DisableDnsPtrRRUpdate -eq $false)
			{
				#default: WS2012 R2
				"  [ ] Disable dynamic updates for DNS PTR records"	| Out-File -FilePath $OutputFile -append
			}
			else
			{
				"  [X] Disable dynamic updates for DNS PTR records"	| Out-File -FilePath $OutputFile -append
			}
			if ($DhcpServerv4DnsSettings.NameProtection -eq $false)
			{
				#default: WS2012 R2
				"  -------------------------------------------------------"	| Out-File -FilePath $OutputFile -append
				"   Name Protection"	| Out-File -FilePath $OutputFile -append
				"     DHCP name protection is disabled at the server level"	| Out-File -FilePath $OutputFile -append
				"     Configure button"	| Out-File -FilePath $OutputFile -append
				"       [ ] Enable Name Protection"	| Out-File -FilePath $OutputFile -append
				"  -------------------------------------------------------"	| Out-File -FilePath $OutputFile -append
			}
			else
			{
				#default: WS2012 R2
				"  -------------------------------------------------------"	| Out-File -FilePath $OutputFile -append
				"   Name Protection"	| Out-File -FilePath $OutputFile -append
				"     DHCP name protection is enabled at the server level"	| Out-File -FilePath $OutputFile -append
				"     Configure button"	| Out-File -FilePath $OutputFile -append
				"       [X] Enable Name Protection"	| Out-File -FilePath $OutputFile -append
				"  -------------------------------------------------------"	| Out-File -FilePath $OutputFile -append
			}
			"---------------------------------------------------------------------------"	| Out-File -FilePath $OutputFile -append
		}
		else
		{
			"This section is only available in WS2012/WS2012R2. Not collecting output since this is an earlier version of the OS."  | Out-File -FilePath $OutputFile -append
			"Please refer to the other DhcpServer and DnsServer output files."  | Out-File -FilePath $OutputFile -append
		}
	}
	else
	{ "The `"DHCP Server`" service is not Running. Not running pscmdlets." 	| Out-File -FilePath $OutputFile -append }
}
else
{ "The `"DHCP Server`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append }
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append



"========================================"	| Out-File -FilePath $OutputFile -append
"[2] DHCP Server DNS Credentials" 	| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append
if ($dhcpServerServiceStatus -ne $null)
{
	if ((Get-Service "DHCPserver").Status -eq 'Running')
	{		
		if ($bn -ge 9200)
		{
			$DhcpDnsCreds = Get-DhcpServerDnsCredential
			if ($DhcpDnsCreds.UserName -eq "")
			{
				"This DHCP Server is NOT configured for DNS Credentials." 	| Out-File -FilePath $OutputFile -append
			}
			else
			{
				"This DHCP Server is configured for DNS Credentials:" 	| Out-File -FilePath $OutputFile -append
				"UserName : " + ($DhcpDnsCreds).UserName 	| Out-File -FilePath $OutputFile -append
				"DomanName: " + ($DhcpDnsCreds).DomainName 	| Out-File -FilePath $OutputFile -append
			}
		}
		else
		{
			"This section is only available in WS2012/WS2012R2. Not collecting output since this is an earlier version of the OS."  | Out-File -FilePath $OutputFile -append
			"Please refer to the other DhcpServer and DnsServer output files."  | Out-File -FilePath $OutputFile -append
		}
	}
	else
	{ "The `"DHCP Server`" service is not Running. Not running pscmdlets." 	| Out-File -FilePath $OutputFile -append }
}
else
{ "The `"DHCP Server`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append }
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append

		
"========================================" 	| Out-File -FilePath $OutputFile -append
"[3] DnsUpdateProxy Group Members" 	| Out-File -FilePath $OutputFile -append
"========================================" 	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
if ($dhcpServerServiceStatus -ne $null)
{
	if ((Get-Service "DHCPserver").Status -eq 'Running')
	{		
		if ($bn -ge 9200)
		{
			# Alternate method using Get-ADGroupMember relies on the AD module, so not using this
			# $DnsUpdateProxyMembers = Get-ADGroupMember -identity DnsUpdateProxy
			
			Add-Type -AssemblyName System.DirectoryServices.AccountManagement
			$ContextType = [System.DirectoryServices.AccountManagement.ContextType]::Domain
			$DnsUpdateProxy = [System.DirectoryServices.AccountManagement.GroupPrincipal]::FindByIdentity($ContextType ,"DnsUpdateProxy")
			$DnsUpdateProxyMembers = $DnsUpdateProxy.GetMembers($true)
			"Members of the DnsUpdateProxy group:"	| Out-File -FilePath $OutputFile -append
			"------------------------------------"	| Out-File -FilePath $OutputFile -append
			$i=0
			foreach ($attribute in $DnsUpdateProxyMembers)
			{
				if (($attribute).SamAccountName -ne $null)
				{
					$i++
					($attribute).SamAccountName	| Out-File -FilePath $OutputFile -append
				}
			}
			"There are $i members of the DnsUpdateProxy group."	| Out-File -FilePath $OutputFile -append
		}
		else
		{
			"This section is only available in WS2012/WS2012R2. Not collecting output since this is an earlier version of the OS."  | Out-File -FilePath $OutputFile -append
			"Please refer to the other DhcpServer and DnsServer output files."  | Out-File -FilePath $OutputFile -append
		}
	}
	else
	{ "The DHCP Server service is not Running. Not running pscmdlets." 	| Out-File -FilePath $OutputFile -append }
}
else
{ "The `"DHCP Server`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append }
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append



"========================================" 	| Out-File -FilePath $OutputFile -append
"[4] DHCP Server registry values" 	| Out-File -FilePath $OutputFile -append
"========================================" 	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
if ($dhcpServerServiceStatus -ne $null)
{
	if ((Get-Service "DHCPserver").Status -eq 'Running')
	{		
		if ($bn -ge 9200)
		{
			$keyPath = "HKLM:\SYSTEM\CurrentControlSet\services\DHCPServer\Parameters"
			if (Test-Path $keyPath)
			{
				$DynamicDNSQueueLength = (Get-ItemProperty -Path $keyPath).DynamicDNSQueueLength
				$DatabaseCleanupInterval = (Get-ItemProperty -Path $keyPath).DatabaseCleanupInterval

				"--------------------------------------------------" 	| Out-File -FilePath $OutputFile -append
				"DHCP Server regvalue DynamicDNSQueueLength" 	| Out-File -FilePath $OutputFile -append
				"--------------------------------------------------" 	| Out-File -FilePath $OutputFile -append
				"RegKey   : $keyPath" 	| Out-File -FilePath $OutputFile -append

				if ($DynamicDNSQueueLength -ne $null)
				{
					"RegValue : DynamicDNSQueueLength" 	| Out-File -FilePath $OutputFile -append
					"RegData  : $DynamicDNSQueueLength" 	| Out-File -FilePath $OutputFile -append
					"`n"	| Out-File -FilePath $OutputFile -append
					"The DynamicDNSQueueLength registry value exists in the registry with a value of $DynamicDNSQueueLength minutes." 	| Out-File -FilePath $OutputFile -append
					"By default, the DynamicDNSQueueLength registry value does NOT exist." 	| Out-File -FilePath $OutputFile -append
				}
				else
				{
					"RegValue : Does not exist" 	| Out-File -FilePath $OutputFile -append
					"`n"	| Out-File -FilePath $OutputFile -append
					"The DynamicDNSQueueLength registry value does not exist. This is the default configuration." 	| Out-File -FilePath $OutputFile -append
					"It may be necessary to increase this value." 	| Out-File -FilePath $OutputFile -append
				}
				"`n"	| Out-File -FilePath $OutputFile -append

				"--------------------------------------------------" 	| Out-File -FilePath $OutputFile -append
				"DHCP Server regvalue DatabaseCleanupInterval" 	| Out-File -FilePath $OutputFile -append
				"--------------------------------------------------" 	| Out-File -FilePath $OutputFile -append
				"RegKey   : $keyPath" 	| Out-File -FilePath $OutputFile -append
				if ($DatabaseCleanupInterval -ne $null)
				{
					"RegValue : DatabaseCleanupInterval" 	| Out-File -FilePath $OutputFile -append
					"RegData  : $DatabaseCleanupInterval" 	| Out-File -FilePath $OutputFile -append
					"`n"	| Out-File -FilePath $OutputFile -append
					"The DatabaseCleanupInterval registry value is set to $DatabaseCleanupInterval minutes." 	| Out-File -FilePath $OutputFile -append
				}
				else
				{
					"RegValue : Does not exist" 	| Out-File -FilePath $OutputFile -append
					"`n"	| Out-File -FilePath $OutputFile -append
					"The DatabaseCleanupInterval registry value does not exist." 	| Out-File -FilePath $OutputFile -append
				}
			}
			else
			{
				"The DHCP Service registry value does not exist. Not doing registry queries."	| Out-File -FilePath $OutputFile -append
			}
		}
		else
		{
			"This section is only available in WS2012/WS2012R2. Not collecting output since this is an earlier version of the OS."  | Out-File -FilePath $OutputFile -append
			"Please refer to the other DhcpServer and DnsServer output files."  | Out-File -FilePath $OutputFile -append
		}
	}
	else
	{ "The `"DHCP Server`" service is not Running. Not running pscmdlets." 	| Out-File -FilePath $OutputFile -append }
}
else
{ "The `"DHCP Server`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append }
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append



"========================================" 	| Out-File -FilePath $OutputFile -append
"[5] DNS Reverse Lookup Zones" 	| Out-File -FilePath $OutputFile -append
"========================================" 	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
if ($dhcpServerServiceStatus -ne $null)
{
	if ((Get-Service "DHCPserver").Status -eq 'Running')
	{		
		if ($bn -ge 9200)
		{
			$DnsServerReverseZonesAuto = new-object PSObject
			$DnsServerReverseZonesAdmin = new-object PSObject
			$DnsReverseZonesCount=0
			$DnsReverseZonesAutoCount = 0
			$DnsReverseZonesAdminCount = 0
			$DnsServerZones = Get-DnsServerZone
			foreach ($Zone in $DnsServerZones)
			{
				if (($Zone).IsReverseLookupZone -eq "True")
				{
					$DnsReverseZonesCount++
					if (($Zone).IsAutoCreated -eq $true) 	#((($Zone).ZoneName -eq "0.in-addr.arpa") -or (($Zone).ZoneName -eq "127.in-addr.arpa") -or (($Zone).ZoneName -eq "255.in-addr.arpa"))
					{
						$DnsReverseZonesAutoCount++
						$ZoneName = ($Zone).ZoneName
						add-member -inputobject $DnsServerReverseZonesAuto -membertype noteproperty -name "Auto $DnsReverseZonesAutoCount" -value $ZoneName
					}
					else
					{
						$DnsReverseZonesAdminCount++
						$ZoneName = ($Zone).ZoneName
						add-member -inputobject $DnsServerReverseZonesAdmin -membertype noteproperty -name "Admin $DnsReverseZonesAdminCount" -value $ZoneName
					}
				}
			}

			"`n"	| Out-File -FilePath $OutputFile -append
			"DNS Reverse Lookup Zones : $DnsReverseZonesCount" 	| Out-File -FilePath $OutputFile -append
			"--------------------------"	| Out-File -FilePath $OutputFile -append
			"Automatically created    : $DnsReverseZonesAutoCount" 	| Out-File -FilePath $OutputFile -append
			"--------------------------"	| Out-File -FilePath $OutputFile -append
			for ($i=1;$i -le $DnsReverseZonesAutoCount;$i++)
			{
				$DnsServerReverseZonesAuto.("Auto $i")		| Out-File -FilePath $OutputFile -append
			}
			"`n"	| Out-File -FilePath $OutputFile -append
			"--------------------------"	| Out-File -FilePath $OutputFile -append
			"Administrator created    : $DnsReverseZonesAdminCount" 	| Out-File -FilePath $OutputFile -append
			"--------------------------"	| Out-File -FilePath $OutputFile -append
			for ($i=1;$i -le $DnsReverseZonesAdminCount;$i++)
			{
				$DnsServerReverseZonesAdmin.("Admin $i")		| Out-File -FilePath $OutputFile -append
			}

			if ($DnsReverseZonesAdminCount -eq 0)
			{
				"*****"	| Out-File -FilePath $OutputFile -append
				"*****ALERT*****"	| Out-File -FilePath $OutputFile -append
				"*****"	| Out-File -FilePath $OutputFile -append
				"No Reverse Lookup Zones have been added by an Administrator."	| Out-File -FilePath $OutputFile -append
				"This is a known cause of failed registration attempts by the DHCP Server that leads to blocking in the DHCP Queue used for DNS registrations."	| Out-File -FilePath $OutputFile -append
			}
		}
		else
		{
			"This section is only available in WS2012/WS2012R2. Not collecting output since this is an earlier version of the OS."  | Out-File -FilePath $OutputFile -append
			"Please refer to the other DhcpServer and DnsServer output files."  | Out-File -FilePath $OutputFile -append
		}
	}
	else
	{ "The `"DHCP Server`" service is not Running. Not running pscmdlets." 	| Out-File -FilePath $OutputFile -append }
}
else
{ "The `"DHCP Server`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append }
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append

	


"========================================" 	| Out-File -FilePath $OutputFile -append
"[6] DNS Permissions for `"Authenticated Users`" on each Active Directory Integrated Zone" 	| Out-File -FilePath $OutputFile -append
"========================================" 	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
if ($dhcpServerServiceStatus -ne $null)
{
	if ((Get-Service "DHCPserver").Status -eq 'Running')
	{		
		if ($bn -ge 9200)
		{
			$dnsZones = get-dnsserverzone

			foreach ($dnsZone in $dnsZones)
			{
				$dnsZoneName = $dnsZone.ZoneName
				$dnsZoneDistinguishedName = $dnsZone.DistinguishedName
				$dnsZoneProperties = get-dnsserverzone -name $dnsZoneName
				$dnsZoneReplicationScope = $dnsZoneProperties.ReplicationScope
				if ($dnsZoneReplicationScope -eq "Forest")
				{
					# example: DC=ToAllDNSserversInThisForest.com,CN=MicrosoftDNS,DC=ForestDnsZones,DC=contoso,DC=com
					$dnsZoneLDAP = [ADSI]"LDAP://$dnsZoneDistinguishedName"
				}
				elseif ($dnsZoneReplicationScope -eq "Domain")
				{
					# example: DC=ToAllDNSserversInThisForest.com,CN=MicrosoftDNS,DC=ForestDnsZones,DC=contoso,DC=com
					$dnsZoneLDAP = [ADSI]"LDAP://$dnsZoneDistinguishedName"
				}
				elseif ($dnsZoneReplicationScope -eq "Legacy")
				{
					# $dnsZone = "ToAllDNSServersInThisDomainW2000"
					$dnsZoneLDAP = [ADSI]"LDAP://$dnsZoneDistinguishedName"
				}
				else
				{
					$dnsZoneLDAP = "NotADIntegrated"
				}

				if ($dnsZoneLDAP -ne "NotADIntegrated")
				{
					$dnsZoneObjectSecurityAccess = $dnsZoneLDAP.ObjectSecurity.Access

					foreach ($dnsZoneObject in $dnsZoneObjectSecurityAccess)
					{
					  $dnsZoneIdentityReference = $dnsZoneObject.IdentityReference
					  $dnsZoneActiveDirectoryRights = $dnsZoneObject.ActiveDirectoryRights

					  if ($dnsZoneIdentityReference -eq "NT AUTHORITY\Authenticated Users")
					  {
						if ($dnsZoneActiveDirectoryRights -eq "CreateChild")
						{
						"-" * 52								| Out-File -FilePath $outputFile -append
						"DNS Zone               : $dnsZoneName" | Out-File -FilePath $OutputFile -append
						"Distinguished Name     : $dnsZoneDistinguishedName" | Out-File -FilePath $OutputFile -append
						"Identity               : $dnsZoneIdentityReference" | Out-File -FilePath $OutputFile -append
						"ActiveDirectoryRights  : $dnsZoneActiveDirectoryRights" | Out-File -FilePath $OutputFile -append
						"This is the default setting."	| Out-File -FilePath $OutputFile -append
						"`n" | Out-File -FilePath $OutputFile -append
						"`n" | Out-File -FilePath $OutputFile -append
						}
						else
						{
						"-" * 52								| Out-File -FilePath $outputFile -append
						"DNS Zone               : $dnsZoneName" | Out-File -FilePath $OutputFile -append
						"Distinguished Name     : $dnsZoneDistinguishedName" | Out-File -FilePath $OutputFile -append
						"Identity               : $dnsZoneIdentityReference" | Out-File -FilePath $OutputFile -append
						"ActiveDirectoryRights  : $dnsZoneActiveDirectoryRights" | Out-File -FilePath $OutputFile -append
						"*****"	| Out-File -FilePath $OutputFile -append
						"*****ALERT*****"	| Out-File -FilePath $OutputFile -append
						"*****"	| Out-File -FilePath $OutputFile -append
						"This is NOT the default setting." | Out-File -FilePath $OutputFile -append
						"`n" | Out-File -FilePath $OutputFile -append
						"`n" | Out-File -FilePath $OutputFile -append
						}
					  }
					}
				}
			}
		}
		else
		{
			"This section is only available in WS2012/WS2012R2. Not collecting output since this is an earlier version of the OS."  | Out-File -FilePath $OutputFile -append
			"Please refer to the other DhcpServer and DnsServer output files."  | Out-File -FilePath $OutputFile -append
		}
	}
	else
	{ "The `"DHCP Server`" service is not Running. Not running pscmdlets." 	| Out-File -FilePath $OutputFile -append }
}
else
{ "The `"DHCP Server`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append }
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append





"========================================" 	| Out-File -FilePath $OutputFile -append
"[7] DHCP Scope DNS Settings" 	| Out-File -FilePath $OutputFile -append
"========================================" 	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
if ($dhcpServerServiceStatus -ne $null)
{
	if ((Get-Service "DHCPserver").Status -eq 'Running')
	{		
		if ($bn -ge 9200)
		{
			$dhcpServerScopes = Get-DhcpServerv4Scope
			foreach ($scope in $dhcpServerScopes)
			{
				"DNS Settings for DHCP Scope: " + $scope.ScopeId | Out-File -FilePath $OutputFile -append
				"----------------------------"  | Out-File -FilePath $OutputFile -append
				$scopeDnsSettings = Get-DhcpServerv4DnsSetting -ScopeId $scope.ScopeId

				"DynamicUpdates             : " + $scopeDnsSettings.DynamicUpdates | Out-File -FilePath $OutputFile -append
				"DeleteDnsRROnLeaseExpiry   : " + $scopeDnsSettings.DeleteDnsRROnLeaseExpiry | Out-File -FilePath $OutputFile -append
				"UpdateDnsRRForOlderClients : " + $scopeDnsSettings.UpdateDnsRRForOlderClients | Out-File -FilePath $OutputFile -append
				"DisableDnsPtrRRUpdate      : " + $scopeDnsSettings.DisableDnsPtrRRUpdate | Out-File -FilePath $OutputFile -append
				"NameProtection             : " + $scopeDnsSettings.NameProtection | Out-File -FilePath $OutputFile -append
				
				if (
					($scopeDnsSettings.DynamicUpdates -eq "OnClientRequest") -and
					($scopeDnsSettings.DeleteDnsRROnLeaseExpiry -eq $true) -and
					($scopeDnsSettings.UpdateDnsRRForOlderClients -eq $false) -and
					($scopeDnsSettings.DisableDnsPtrRRUpdate -eq $false) -and
					($scopeDnsSettings.NameProtection -eq $false)
					)
				{
					"These are the default settings."	| Out-File -FilePath $OutputFile -append
				}
				else
				{
					"**********"	| Out-File -FilePath $OutputFile -append
					"These are NOT the default settings."	| Out-File -FilePath $OutputFile -append
					"**********"	| Out-File -FilePath $OutputFile -append
				} 
				"`n"	| Out-File -FilePath $OutputFile -append
				"`n"	| Out-File -FilePath $OutputFile -append
			}
		}
		else
		{
			"This section is only available in WS2012/WS2012R2. Not collecting output since this is an earlier version of the OS."  | Out-File -FilePath $OutputFile -append
			"Please refer to the other DhcpServer and DnsServer output files."  | Out-File -FilePath $OutputFile -append
		}
	}
	else
	{ "The `"DHCP Server`" service is not Running. Not running pscmdlets." 	| Out-File -FilePath $OutputFile -append }
}
else
{ "The `"DHCP Server`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append }
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append


CollectFiles -filesToCollect $OutputFile -fileDescription "Dynamic DNS Updates Server" -SectionDescription $sectionDescription
	



# SIG # Begin signature block
# MIIjlQYJKoZIhvcNAQcCoIIjhjCCI4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBvFydHXGbGHMd5
# vxeyuC94ye8jl3EkRlFDxGYXX56GI6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVajCCFWYCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgkPMuDFkn
# VSFRHN4BSIsr1f1Mb2MvUXfTc2aD0EjVGJowOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAGYO5TM1gvu8A6XktHbgB7iRn2THpqxXneMy9LU0g/d5YrdCqgl0vuo9
# Ivb01h+zcpKs9r8oQ4X3dUSeLAfxdYcKql+1aEjOhVvjgk93/2e3MiUBsBwA0l3B
# bXkylgwF9ZlxKazXzIH6sf5wwVCZkGO/43GuaV/SXaHfQsOXWjrYkbCLGHlCxNWR
# JXPnaIk1Bsnmoy2mwcw9auKSStyctKpwLoB0eBQ2fEMvUJd/91rS+i/hDpxJAcM1
# gIgOyv22/X7LZo8NP2PnaeYN5105PbOxjkoZTWm+8tvVlAMNXJmZJ8et+cgWV/6A
# LBuBuR1fLFPi61n46MlYrGdNOv6aIDChghL+MIIS+gYKKwYBBAGCNwMDATGCEuow
# ghLmBgkqhkiG9w0BBwKgghLXMIIS0wIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYL
# KoZIhvcNAQkQAQSgggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQg5BLot+4k3oqwQt9cfkauEOGh/6Psl0wAC5Bs608641YCBmBjTFo+
# +xgTMjAyMTA1MTkyMjIzNTguNTU5WjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjpFMDQxLTRCRUUtRkE3RTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCDk0wggT5MIID4aADAgECAhMzAAABN0GPQ+daW2+nAAAAAAE3MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIw
# MTAxNTE3MjgxNFoXDTIyMDExMjE3MjgxNFowgdIxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RTA0MS00
# QkVFLUZBN0UxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDEEe5p0SWbcbm2KSFPONIM
# HT72xeZSFTINVGPRji/P2tn2zKQ2hsvn/oC3nM6R4HZuX0he9V3JL9kk1lPfveSf
# OtDfjvPfQybDv75VT8IT7jHjD2RvlupAd9LNslC3oqZay4yYkvODhHkx4mzkxjlh
# 08vGgygNFxOL/8qgwVHQrNLX/fbgPb/gqQcPVe36zTFjQMgJQ4rVFuYkIoSAE/X8
# YNmO5lAFL0OLz3JOe8slX4uvVC2uIfgSqZGgB2ZXfMnQYmyvm+EY+Yp848JFKTtD
# yKBfuCgWcIvOlhx8cYKqhH+bD3mB9CnDKZXDFkHQ+QYytDD4spU9r8Uc/gLgo75B
# AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQUDWCwcwz652BjusSd7ro7LPGUT2UwHwYD
# VR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGlt
# U3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEF
# BQcDCDANBgkqhkiG9w0BAQsFAAOCAQEAnfZT133RFW4BRv02ydcEbUrjaqOFT6Me
# /AF1uKkhxfhaDt0fll25BmPeBaAoANnnP5N6FfsacFuLbrlUjvENGwV7YKORObgk
# iiKx0rBgEOu5L5hFEEbgHURG5aLnhcbDH6VID6JA2siLombQIv8x9Au/Cyo8lIY/
# r04QcLJoTGizjzr5fclO4ZXXUIGX8E7uvxQdvH+sTp9muVllhpsgXpp5qG9MvXgu
# 9ktX9szNhI4OxuMcexOb1BoabWKOFqAJ1uQCqvz7scCBgRqvxc+XPFSFUjhKFUHl
# kZ32BnbIGTDF0DSgVzvjlN04+ts/v293R4+qC8kMfm2Q6FNE0jnldDCCBnEwggRZ
# oAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1
# MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ
# 1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP
# 8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRh
# Z5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39
# dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2
# iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGj
# ggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB
# /wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFv
# s+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5
# U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFS
# AK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1V
# ry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6
# f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35j
# WSUPei45V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHa
# sFAeb73x4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLN
# HfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4
# sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHX
# odLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUe
# CLraNtvTX4/edIhJEqGCAtcwggJAAgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjpFMDQxLTRCRUUtRkE3RTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUA6ruoOTiJXPwhO5ltQWsAbt5zGpyggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUF
# AAIFAORPtCUwIhgPMjAyMTA1MTkyMzU4MjlaGA8yMDIxMDUyMDIzNTgyOVowdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA5E+0JQIBADAKAgEAAgIXOAIB/zAHAgEAAgIR
# gDAKAgUA5FEFpQIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAFnaSI48yVkw
# 4cC3G2dDbrOOmdP+ZLp+gMg++PL5rSSb5I+Jhq+mv4oa081KR6BNbJRZ04fTf8mK
# I5w0Jq+1fM/SV6qMbp1ig7fhz6zMxeXkmhqw6rXbbNzeFC0lGTXSifTc1At0xMxj
# /py93HcG7Ik2/1FjJlLAKMVBw61mFnBxMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAE3QY9D51pbb6cAAAAAATcwDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQgKRZSnfUuYhMVMcwad7SAGbhnpc4/aGGseK5dXL5PZ78wgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCAdWX6vwJ4EnSLJf9oZkPZhtDuCT5Ts3sFC
# JMMoBhIcEDCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABN0GPQ+daW2+nAAAAAAE3MCIEIEFC3ANrREfyUIPRAbC54GuLTD0unKmsQ/4k
# fbYKwF+cMA0GCSqGSIb3DQEBCwUABIIBAATj5wluqxFyeoCWpTlYKbfJV0TT8uyX
# bugcYK8qsdZB7/7sURq4z4kxky8otceGpcbyJG4+rrYmbQy4wgIpJUrsSpTrLab5
# TdkP7wVmzacuWCFJAnWNXJMg07G6eJghUcY3eD99V0kFzZx++2P3qBBaTdEgjn75
# FBKbGixrUVpiMUeIwHBTRf3e5A2G9glSrj6pyMamDmrQ0ABAqmEgRHRA6inI+yXi
# a576dW8QAn0j/nXHRTdc4vjvy5Q4gsn2nkNPCNrgidDlXMPYJexKbx0ZzVi4lnwl
# T3o0PfPxXQTOO2/KBUV1HwN3WViFcfHfRB6jK1iOc3KbjTKi9ifcs2Y=
# SIG # End signature block
