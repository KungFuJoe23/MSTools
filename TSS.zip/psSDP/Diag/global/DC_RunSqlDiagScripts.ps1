# DC_RunSqlDiagScripts.ps1 
# This script has dependencies on utils_CTS and utils_DSD
#
param( [Object[]] $instances, [switch]$CollectSqlDiag, [switch]$CollectAlwaysOnInfo ) 

#_# SQLDIAG script name for SQL Server 2014
New-Variable SQL_SCRIPT_SQLDIAG_2014  -Value "sp_sqldiag12.sql"          -Option ReadOnly

# SQLDIAG script name for SQL Server 2012
New-Variable SQL_SCRIPT_SQLDIAG_2012  -Value "sp_sqldiag11.sql"          -Option ReadOnly

# SQLDIAG script name for SQL Server 2008 and SQL Server 2008 R2
New-Variable SQL_SCRIPT_SQLDIAG_2008  -Value "sp_sqldiag10.sql"          -Option ReadOnly

# SQLDIAG script name for SQL Server 2005
New-Variable SQL_SCRIPT_SQLDIAG_2005  -Value "sp_sqldiag09.sql"           -Option ReadOnly

# SQL 2012 Always-On 
New-Variable SQL_SCRIPT_ALWAYSON      -Value "AlaysOnDiagScript.sql"     -Option ReadOnly

#
# Function : Run-SqlScript
# ----------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Public - You should call this script if you want to collect SQLDIAG script output 
#
# Description:
# 			This function runs various SQL Server diagnostic scripts and collects the output
#			This is an "online" snapshot collector that utilizes SQLCMD 
# 
# Arguments:
#			$InstanceName
#				Function will find the path to the errorlogs for the instance passed 
#			$NetName
#				This is the server or virtual SQL network name to connect to
# 
# Owner:
#			DanSha 
#
function Run-SqlScript ([string]$SqlServerName, [string]$ScriptToExecute, [string]$OutFileName, [string]$SectionDescription, [string] $FileDescription )
{
	$Error.Clear()           
	trap 
	{
		"[Run-AlwaysOnScript] : [ERROR] Trapped exception ..." | WriteTo-StdOut
		Report-Error
	}
	
    if ($null -ne $SqlServerName)
    {
        if ($null -ne $ScriptToExecute)
        {
            if ($null -ne $OutFileName)        
            {    
                if ($null -ne $SectionDescription)
                {
                    if ($null -ne $FileDescription)
                    {
                        # Validate existence of script before calling Execute-SqlScript
                    	if ($true -eq (Test-Path -Path $ScriptToExecute -PathType Leaf))
                        {
                            # Write status to debug log
                        	"[Run-SqlDScript] : [INFO] Attempting to collect SQL Server Configuration information for instance: {0} using script: [{1}] as input and writing output to file: [{2}]" -f $SqlServerName, (Join-Path $PWD.Path "sqldiag_proc.sql"), (Join-Path $PWD.Path $SqlDiagOutFileName) | WriteTo-StdOut
                    	
                    	    Execute-SqlScript -ConnectToName $SqlServerName -ScriptToExecute $ScriptToExecute -OutputFileName $OutFileName -SectionDescription $SectionDescription -FileDescription "SQLDIAG"
                        }
                        else
                        {
                            "[Run-SqlScript] : [ERROR] Input file: [{0}] not found in current directory: [{1}]" -f $ScriptToExecute, $PWD.Path  | WriteTo-StdOut
                        }
                    
                    } # if ($null -ne $FileDescription)
                    else
                    {
                        '[Run-SqlScript] : [ERROR] Required parameter -FileDescription was not specified.' | WriteTo-StdOut
                    }
                    
                } # if ($null -ne $SectionDescription)
                else
                {
                    '[Run-SqlScript] : [ERROR] Required parameter -SectionDescription was not specified.' | WriteTo-StdOut
                }
                
            } # if ($null -ne $OutFileName)   
            else
            {
                '[Run-SqlScript] : [ERROR] Required parameter -OutFileName was not specified.' | WriteTo-StdOut
            }     
            
        } #   if ($null -ne $ScriptToExecute)
        else
        {
            '[Run-SqlScript] : [ERROR] Required parameter -ScriptToExecute was not specified.' | WriteTo-StdOut
        } 
        
    } # if ($null -ne $InstanceName)
    else
    {
        '[Run-SqlScript] : [ERROR] Required parameter -SqlServerName was not specified.' | WriteTo-StdOut
    }
    
} # function Run-Sqlcript()


function Get-SQlServerName([string]$InstanceName, [string]$NetName)
{
    trap 
    {
    	"[Get-SQlServerName] : [ERROR] Trapped exception ..." | WriteTo-StdOut
    	Report-Error
    }
    
    if ($null -ne $InstanceName)
    {
    	
        if ($null -ne $NetName)
        {
            if (('DEFAULT' -eq $InstanceName.ToUpper()) -or ('MSSQLSERVER' -eq $InstanceName.ToUpper()))
        	{
        		$ConnectToName = $NetName
            } 
            else 
            {
                $ConnectToName = $NetName+"\"+$InstanceName
          	}
        }
        else
        {
            '[Get-SQlServerName] : [ERROR] Required parameter -NetName was not specified.' | WriteTo-StdOut
        }
    }
    else
    {
        '[Get-SQlServerName] : [ERROR] Required parameter -InstanceName was not specified.' | WriteTo-StdOut
    }

    if ($true -eq $global:SQL:debug)
    {
        "[Get-SQlServerName] : [DEBUG] SQL Server name is: [{0}]" -f $ConnectToName | WriteTo-StdOut
    }
    
    return ($ConnectToName)
}

function Run-SqlDiagScript([PSobject]$InstanceVector)
{
    trap
    {
        '[Run-SqlDiagScript] : [ERROR] Trapped exception ...'
        Report-Error
    }

    if ($null -ne $InstanceVector) 
    {
        
        if (($null -ne $InstanceVector.NetName) -and ($null -ne $InstanceVector.InstanceName))
        {
            # Outfile name
            $SqlDiagOutFileName = "{0}_{1}_{2}_sp_sqldiag_Shutdown.OUT" -f $InstanceVector.NetName, $InstanceVector.InstanceName, (Get-LcidForSqlServer -SqlInstanceName $InstanceVector.InstanceName)

            # Script needs server name to connect to. Generate it 
            $SqlServerConnectToName = Get-SQlServerName -InstanceName $InstanceVector.InstanceName -NetName $InstanceVector.NetName
            
            Write-DiagProgress -Activity $sqlConfigurationCollectorStrings.ID_SQL_CollectSqlConfiguration -Status ($sqlConfigurationCollectorStrings.ID_SQL_CollectSqlConfigurationDesc + ": " + $instance.InstanceName)
            
            [string]$SqlDiagScriptFile=$null
            
            if ($null -ne $InstanceVector.SqlVersionMajor)
            {
                if ($global:SQL:SQL_VERSION_MAJOR_SQL2005 -eq $InstanceVector.SqlVersionMajor)
                {
                    $SqlDiagScriptFile=$SQL_SCRIPT_SQLDIAG_2005
                }
                elseif (($global:SQL:SQL_VERSION_MAJOR_SQL2008 -eq $InstanceVector.SqlVersionMajor) -or ($global:SQL:SQL_VERSION_MAJOR_SQL2008R2 -eq $InstanceVector.SqlVersionMajor))
                {
                    $SqlDiagScriptFile=$SQL_SCRIPT_SQLDIAG_2008
                }
                elseif ($global:SQL:SQL_VERSION_MAJOR_SQL2012 -eq $InstanceVector.SqlVersionMajor) 
                {
                    $SqlDiagScriptFile=$SQL_SCRIPT_SQLDIAG_2012
                }
                elseif ($global:SQL:SQL_VERSION_MAJOR_SQL2014 -eq $InstanceVector.SqlVersionMajor) 
                {
                    $SqlDiagScriptFile=$SQL_SCRIPT_SQLDIAG_2014
                }
                else
                {
                    $SqlDiagScriptFile=$SQL_SCRIPT_SQLDIAG_2014
                    '[Run-SqlDiagScript] : [ERROR] Unexpected server major version: [{0}].  SQL Diag script will assume latest version' -f $InstanceVector.SqlVersinoMajor | WriteTo-StdOut
                }
            	
                if (($null -ne $SqlDiagScriptFile) -and ([String]::Empty -ne $SqlDiagScriptFile))
                {
                    # Call wrapper to validate parameters and call Execte-SqlScript 
                    Run-SqlScript -SqlServerName $SqlServerConnectToName -ScriptToExecute $SqlDiagScriptFile -OutFileName $SqlDiagOutFileName -SectionDescription ("SQL Server Diagnostic Scripts for instance: {0}" -f $SqlServerConnectToName) -FileDescription 'SQLDIAG'
                }
                
            } # if ($null -ne $InstanceVector.SqlVersionMajor)
            else
            {
                '[Run-SqlDiagScript] : [ERROR] SqlVersionMajor value in the InstanceVector is null' | WriteTo-StdOut
            }
            
        } # if (($null -ne $InstanceVector.NetName) -and ($null -ne $InstanceVector.InstanceName))
        else
        {
            '[Run-SqlDiagScript] : [ERROR] Either the InstanceName: [{0}] or NetName: [{1}] was null in the passed InstanceVecor' -f $InstanceVector.InstanceName, $InstanceVector.NetName | WriteTo-StdOut
        }
        
    } # if ($null -ne $InstanceVector) 
    else
    {
        '[Run-SqlDiagScript] : [ERROR] Required parameter -InstanceVector was not specified' | WriteTo-StdOut
    }

}

function Run-SqlAlwaysOnDiagScript([PSobject]$InstanceVector)
{
    trap
    {
        '[Run-SqlAlwaysOnDiagScript] : [ERROR] Trapped exception ...'
        Report-Error    
    }
    
    if ($null -ne $InstanceVector) 
    {
        if (($null -ne $InstanceVector.NetName) -and ($null -ne $InstanceVector.InstanceName))
        {
            # Outfile name
            $AlwaysOnOutFileName = "{0}_{1}_{2}_AlwaysOn.OUT" -f $InstanceVector.NetName, $InstanceVector.InstanceName, (Get-LcidForSqlServer -SqlInstanceName $InstanceVector.InstanceName)

            # Script needs server name to connect to. Generate it 
            $SqlServerConnectToName = Get-SQlServerName -InstanceName $InstanceVector.InstanceName -NetName $InstanceVector.NetName
          
            # Update dialog with current progress
            Write-DiagProgress -Activity $sqlConfigurationCollectorStrings.ID_SQL_CollectSqlConfiguration -Status ($sqlConfigurationCollectorStrings.ID_SQL_CollectSqlAlwaysOnDesc + ": " + $InstanceVector.InstanceName)
           
            Run-SqlScript -SqlServerName $SqlServerConnectToName -ScriptToExecute $SQL_SCRIPT_ALWAYSON -OutFileName $AlwaysOnOutFileName -SectionDescription ("SQL Server Diagnostic Scripts for instance: {0}" -f $InstanceVector.InstanceName) -FileDescription 'AlwaysOn'
        
        } # if (($null -ne $InstanceVector.NetName) -and ($null -ne $InstanceVector.InstanceName))
        else
        {
            '[Run-SqlAlwaysOnDiagScript] : [ERROR] Either the InstanceName: [{0}] or NetName: [{1}] was null in the passed InstanceVecor' -f $InstanceVector.InstanceName, $InstanceVector.NetName | WriteTo-StdOut
        }
        
    } # if ($null -ne $InstanceVector) 
    else
    {
        '[Run-SqlAlwaysOnDiagScript] : [ERROR] Required parameter -InstanceVector was not specified' | WriteTo-StdOut
    }
    
} # function Run-SqlAlwaysOnDiagScript()

$Error.Clear()           
trap 
{
	"[DC_GetSqlServerConfiguration] : [ERROR] Trapped exception ..." | WriteTo-StdOut
	Report-Error
}
	
Import-LocalizedData -BindingVariable sqlConfigurationCollectorStrings

if ($true -eq $global:SQL:Debug)
{
    $CollectSqlDiag=$true
	$CollectAlwaysOnInfo=$true
}

# Check to be sure that there is at least one SQL Server installation on target machine before proceeding
#
if (Check-SqlServerIsInstalled -eq $true)
{
	# If $instance is null, get errorlogs for all instances installed on machine
	#
	if ($null -eq $instances)
	{
		$instances = Enumerate-SqlInstances -Offline
	}

	if ( $instances -ne $null )
	{
		foreach ($instance in $instances)
		{
            if ('DEFAULT' -eq $instance.InstanceName.ToUpper()) {$instance.InstanceName = 'MSSQLSERVER'} 
            
			if ($global:SQL:SERVICE_STATUS_RUNNING -eq $instance.ServiceStatus)
			{
                
                if ($true -eq $CollectSqlDiag)
                {
            		Run-SqlDiagScript -InstanceVector $instance
                }
                
                # If this is a SQL 2012 instance we will collect AlwaysOn information if so directed
                if (($global:SQL:SQL_VERSION_MAJOR_SQL2012 -le $instance.SqlVersionMajor) -and ($true -eq $CollectAlwaysOnInfo))
                {
                    Run-SqlAlwaysOnDiagScript -InstanceVector $instance                    
                }
                
			} 
			else 
			{
				"[DC_GetSqlServerConfiguration] : [INFO] Diagnostic scripts will not be collected for instance {0} because it is not started.  Current status is: {1}" -f $instance.InstanceName, $instance.ServiceStatus | WriteTo-StdOut
    		}
            
        } # foreach ($instance in $instances)
        
	} # if ( $instances -ne $null )
    else
    {
        "[DC_GetSqlServerConfiguration] : [ERROR] SQL Server appears to be installed on server: [{0}] yet no installed instances were found" -f $env:ComputerName | WriteTo-StdOut
    }
}
else 
{
    "[DC_GetSqlServerConfiguration] : No sql server instances are installed on: [{0}]" -f $ComputerName | WriteTo-StdOut 
}
    

# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCEfe10KPzDudtp
# gtvQfoJ5h+aJpsFVpvZ3TgqliVZPKKCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgfi5dNrpB
# 17gy0i8ZORYisDPdM27g1GENtdaiQTh6Bz0wOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBABd+5gOtQ0kBHCsb9ctjj+P8Sy3zRZcFxmcskkCyT5Q2bigugVb3VvPb
# tvAdn8/184zF5gUCPoYwz66S0RIAogOVKK1s+NoVC9/ZlvEP7xmATRpLhm8BKwG9
# 6RywGjTm4C1ltYCUSjxTu3xr5IJ5X7thOwH7CB2gl9YSmBXJuvRJ1bDfrD6LKM5T
# k1Tlyjg2q8Ya+Avx118hGChBzLsIKcpPrXBlVKsOgUBe5Hy5ogJz1x8oyTzUXqKk
# IhfBTd3nVwlTKwGVuCqdX3QGf/DMsCWzaROzatNYahw1JVACWBhagCVMpAzKwDFM
# rUX+tUeAmXISQPgQsb28BnHCimKjoPShghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgWk6x1/YTjb0THb3PGZLzxlsE+LfEbVwLDW6DCUg6Ew8CBmCJ5igz
# KxgTMjAyMTA1MTkyMjI1MDMuOTIyWjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjRE
# MkYtRTNERC1CRUVGMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFfw65lVuVTWOwAAAAAAV8wDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE5WhcNMjIwNDExMTkwMjE5WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjREMkYtRTNERC1CRUVG
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAvD15+YLZZD25prDuTiDEdJIISgkuTbYV
# MBoXyNhsAyRALoNAXRY+ciF4szURFO5D0VZuCV/SZdsN3YqN7NE2XPnfJwkhF6IZ
# RA6fDm93hOCMtTEvXuDcrQw/ac2Fj8vI/3wyX/jRf3Tl6ANuIid1l20eINvXF9jX
# tru/WP2jea5z4wKAW31875TgIM1SkwwxAkWv/1CVThh0lrCNvIp8rcu2+p+reW+A
# rT8emGIO1flyHdt4Y0EqjApJNeF+3ynC5dA+ui61aAHk9mYA3xdmEAKjiNaL9rTO
# AAklwGqhe9LoietZwf8SqL+pVqPxWznr9n/qRphlm7/WZLMufkQAswIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFCXs6dOVzSuBnsV3uqUMWC5hNTj1MB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAA6C19kslhJuwTdbved3SEuepCodIWXaykfHN5fEzi4l
# Pa4BWT9ItXPOO9l6ZQMF4550p5cbyFy2mumhAylTeBuw1SdRoN6wNyZH54QsLBhr
# 5UGRQKqwgYmZCUPC4PA1rruTIIQ/I9bn1i7bD92M2vA1ZKO25HB9QWgOSNjIOOdc
# PSOiyLrurEmBbytGqOX1rraEbOXOAT5pUtNPkiErnPZfrYumHyP1/heO0I+fJ4Uo
# WaAFYc9jUdtuNQd+D3VK0IvG54fYuNmhARNY4n6nESWJxfBU/kHTCVaSJq7C6Det
# MqcNvlYpRvaWWydCBp6BX4xCMwjsrq/6ym+wyBGM+WEwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjREMkYtRTNERC1C
# RUVGMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQD6B9KqN0Cd04URpc5DIEJ26mZCh6CBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5E9qrjAiGA8y
# MDIxMDUxOTE0NDUwMloYDzIwMjEwNTIwMTQ0NTAyWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDkT2quAgEAMAoCAQACAiO/AgH/MAcCAQACAhE5MAoCBQDkULwuAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAecsoRTUlhEQz6kbFbft7/nMdZmWw
# gVe+b6xz9Rk5YIkNtgmrvPpxnPjiNC3iD5f+Hcyg/IN5ayxXP53EJkg4tm2mZx9H
# srM6P4p7PpgTlmk/Ysb2xfQin+Mgoj+E4/sM0WQSH28mLwr0N93Ie70O+5Vv0F59
# oPgjVOotpbRGk9AxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAV/DrmVW5VNY7AAAAAABXzANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCA36AAA
# eHa4Sq7+7sSJljPLvIVhGWU1yUlZncUpX63uvjCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EINDNerUrEawu6PSzOS2ueWEhGqZvCnltUZzoG7qGCUxcMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFfw65lVuVTWOwA
# AAAAAV8wIgQgoaSQVJpAP8XS/u3a9RVKNgNI7AgodpzsYtL51hY0ddkwDQYJKoZI
# hvcNAQELBQAEggEAPBNebPg75E4yTxvgz3ScOI3AH3OfJyHxQ3i6cmLBaFOKoScl
# 2FOibpuj7K9wgvKu9NxFtKiVy0VIqFUcsUgkTaymT9jzYV4TnWG02zoHseIKef1W
# tv7URCF2zbDRng1TGfMgEvBI+fqzVLz64hEX5Fjk6LgQKoHFRuhk6FHiB6WkJs+V
# fNgwdfioAyVGCmGSffHf2jgowANsgo6VJl9R7OHMq5rRD7uesg81JcIhMEH77y1P
# kzYot9AXV7aTQpSxNxyhkYUV2o+CrbxsYUGP7AwWf+eJyLxusx2o8SsvaYJiQBCu
# pPtLx+ZWumy5QmzWO67Dp2o4U/inNIsU+Uvu4Q==
# SIG # End signature block
