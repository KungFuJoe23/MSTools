#************************************************
# DC_Setup_Addons.ps1
# Version 1.1
# Date: 2009-2019
# Author: Walter Eder (waltere@microsoft.com)
# Description: Collects additional Setup information.
# Called from: TS_AutoAddCommands_Setup.ps1
#*******************************************************

Param($MachineName = $Computername, $Path = "")

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Write-verbose "$(Get-Date -UFormat "%R:%S") : Start of script DC_Setup_Addons.ps1"

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status $ScriptVariable.ID_CTSAddonsDescription


# detect OS version
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

function isOSVersionAffected
{
	if ([int]$bn -gt [int](9600))
	{
		return $true
	}
	else
	{
		return $false
	}
}

function RunNet ([string]$NetCommandToExecute="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSSMBClient -Status "net $NetCommandToExecute"
	
	$NetCommandToExecuteLength = $NetCommandToExecute.Length + 6
	"`n`n`n" + "=" * ($NetCommandToExecuteLength) + "`r`n" + "net $NetCommandToExecute" + "`r`n" + "=" * ($NetCommandToExecuteLength) | Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c net.exe " + $NetCommandToExecute + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n`n`n" | Out-File -FilePath $OutputFile -append
}


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n`n`n" | Out-File -FilePath $OutputFile -append
}

#--- Section CBS & PNP info, components hive, SideBySide hive, Iemain.log
$sectionDescription = "Windows logs folders"

if(test-path (join-path $Env:windir "Logs"))
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Compress \Logs"
	$DestinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
	Copy-Item "$env:WinDir\Logs" -Destination $DestinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
	CompressCollectFiles -filesToCollect $DestinationTempFolder -DestinationFileName ($ComputerName + "_Windows-Logs.zip") -fileDescription "Windows Log Folder" -sectionDescription $sectionDescription -Recursive
	Remove-Item $DestinationTempFolder -Force -Recurse
}
if(test-path (join-path $Env:windir "System32\LogFiles"))
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Compress \System32\LogFiles"
	$DestinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
	Copy-Item "$env:WinDir\System32\LogFiles" -Destination $DestinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
	CompressCollectFiles -filesToCollect $DestinationTempFolder -DestinationFileName ($ComputerName + "_Windows-System32-Logs.zip") -fileDescription "System32 LogFiles Folders" -sectionDescription $sectionDescription -Recursive
	Remove-Item $DestinationTempFolder -Force -Recurse
}

Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status (join-path $Env:windir "Servicing\Sessions")
$arrWindirLogsFiles = get-childitem -force -path (join-path $Env:windir "Servicing\Sessions") -recurse -exclude *.temp,*.tmp | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
CompressCollectFiles -filesToCollect $arrWindirLogsFiles -fileDescription "Windows\Servicing\Sessions folder" -sectionDescription "Servicing\Sessions Folder" -DestinationFileName ($MachineName + "Windows-Servicing-Sessions.zip") -RenameOutput $true -recursive 

Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status (join-path $Env:windir "inf")
$arrWindirLogsFiles = get-childitem -force -path (join-path $Env:windir "inf\*") -include *.log | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
CompressCollectFiles -filesToCollect $arrWindirLogsFiles -fileDescription "Windows\inf\*.log" -sectionDescription "inf\*.log" -DestinationFileName ($MachineName + "Windows-Inf-logs.zip") -RenameOutput $true -recursive 

	$filesToCollect = "$env:WinDir\servicing\sessions\sessions.xml"
	$filesDescription = "servicing\sessions\sessions.xml"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -RenameOutput $true -MachineNamePrefix $ComputerName
	}

	$filesToCollect = "$env:WinDir\Logs\MoSetup\UpdateAgent.log"
	$filesDescription = "MoSetup\UpdateAgent.log"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -RenameOutput $true -MachineNamePrefix $ComputerName
	}

	$filesToCollect = "$env:WinDir\iemain.log"
	$filesDescription = "iemain.log"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -RenameOutput $true -MachineNamePrefix $ComputerName
	}

#----------Registry
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Collect Registry files"

	$OutputFile= $MachineName + "_reg_Component_Based_Servicing.HIV"
	RegSave -RegistryKey "HKLM\Software\Microsoft\Windows\CurrentVersion\Component Based Servicing" -OutputFile $OutputFile -fileDescription "Components CBS Hive"

	$OutputFile= $MachineName + "_reg_SideBySide.HIV"
	RegSave -RegistryKey "HKLM\Software\Microsoft\Windows\CurrentVersion\SideBySide" -OutputFile $OutputFile -fileDescription "SideBySide Hive"

	$OutputFile= $MachineName + "_reg_SideBySide.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\SideBySide" -OutputFile $OutputFile -fileDescription "SideBySide Reg key" -Recursive $true
		
#----------Registry Section Misc Registry Info
	$OutputFile= $MachineName + "_reg_Langpack.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\MUI\UILanguages" -OutputFile $OutputFile -fileDescription "Langpack Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_services.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Services" -OutputFile $OutputFile -fileDescription "services Reg key" -Recursive $true
	$OutputFile= $MachineName + "_reg_services.HIV"
	RegSave -RegistryKey "HKLM\System\CurrentControlSet\Services" -OutputFile $OutputFile -fileDescription "services Reg Hive" -Recursive $true
			
	$OutputFile= $MachineName + "_reg_CurrentVersion.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion" -OutputFile $OutputFile -fileDescription "Windows NT\CurrentVersion Reg key" -Recursive $true
	$OutputFile= $MachineName + "_reg_CurrentVersion.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion" -OutputFile $OutputFile -fileDescription "Windows\CurrentVersion Reg key" -Recursive $true
	
	$OutputFile= $MachineName + "_reg_BuildInfo.txt"
	$RegKeysValues = "BuildLab", 
					"BuildLabEx", 
					"UBR", 
					"ProductName"
	RegQueryValue -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion" -RegistryValues $RegKeysValues -OutputFile $OutputFile -fileDescription "BuildInfo" -CollectResultingFile $true
	
	$OutputFile= $MachineName + "_reg_AppModelVersion.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\AppModel" -OutputFile $OutputFile -fileDescription "AppModel Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_FirmwareResources.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\FirmwareResources" -OutputFile $OutputFile -fileDescription "FirmwareResources Reg key" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\AppModel" -OutputFile $OutputFile -fileDescription "AppModel Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Appx.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Appx" -OutputFile $OutputFile -fileDescription "Appx Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Superfetch.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\Superfetch" -OutputFile $OutputFile -fileDescription "Superfetch Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Uninstall.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Uninstall" -OutputFile $OutputFile -fileDescription "Uninstall Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall" -OutputFile $OutputFile -fileDescription "Uninstall Reg keys" -Recursive $true

	$OutputFile= $MachineName + "_reg_Recovery.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\CrashControl" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\Session Manager" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\Session Manager\Memory Management" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\AeDebug" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\Windows Error Reporting" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true

	$OutputFile= $MachineName + "_reg_Startup.txt"
	RegQuery -RegistryKeys "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" -OutputFile $OutputFile -fileDescription "Startup Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Runonce" -OutputFile $OutputFile -fileDescription "Startup Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\ShellServiceObjectDelayLoad" -OutputFile $OutputFile -fileDescription "Startup Reg keys" -Recursive $true

	$OutputFile= $MachineName + "_reg_TimeZone.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\TimeZoneInformation" -OutputFile $OutputFile -fileDescription "TimeZone Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\Time Zones" -OutputFile $OutputFile -fileDescription "TimeZone Reg keys" -Recursive $true

	$OutputFile= $MachineName + "_reg_TermServices.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\Terminal Server" -OutputFile $OutputFile -fileDescription "TermServices Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_SVCHost.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\SvcHost" -OutputFile $OutputFile -fileDescription "SVCHost Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_ProfileList.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\ProfileList" -OutputFile $OutputFile -fileDescription "ProfileList Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_DriverDatabase.HIV"
	RegSave -RegistryKey "HKLM\System\DriverDatabase" -OutputFile $OutputFile -fileDescription "DriverDatabase Hive"
	$OutputFile= $MachineName + "_reg_DriverDatabase.txt"
	RegQuery -RegistryKeys "HKLM\System\DriverDatabase" -OutputFile $OutputFile -fileDescription "DriverDatabase Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_.NET-Framework-Setup.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\NET Framework Setup\NDP" -OutputFile $OutputFile -fileDescription ".NET-Framework-Setup Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Winevt.HIV"
	RegSave -RegistryKey "HKLM\Software\Microsoft\Windows\currentversion\winevt" -OutputFile $OutputFile -fileDescription "Winevt Hive"
	$OutputFile= $MachineName + "_reg_Winevt.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\currentversion\winevt" -OutputFile $OutputFile -fileDescription "Winevt Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Setup.txt"
	RegQuery -RegistryKeys "HKLM\System\Setup" -OutputFile $OutputFile -fileDescription "Setup Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Setup\OOBE" -OutputFile $OutputFile -fileDescription "Setup Reg keys"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Setup\State" -OutputFile $OutputFile -fileDescription "Setup Reg keys"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Setup\Sysprep" -OutputFile $OutputFile -fileDescription "Setup Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Setup\SysPrepExternal" -OutputFile $OutputFile -fileDescription "Setup Reg keys" -Recursive $true

	$OutputFile= $MachineName + "_reg_WMI.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\WMI" -OutputFile $OutputFile -fileDescription "WMI Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Drivers.HIV"
	RegSave -RegistryKey "HKLM\DRIVERS" -OutputFile $OutputFile -fileDescription "Drivers Hive"

#----------Directory listing 
	$sectionDescription = "Dir $env:WinDir\Winsxs\temp"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_dir_winsxsTEMP.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "$env:WinDir\Winsxs\temp" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription $fileDescription -sectionDescription $sectionDescription

	$sectionDescription = "Dir $env:WinDir\Winsxs"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_dir_winsxs.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "$env:WinDir\Winsxs" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription $fileDescription -sectionDescription $sectionDescription
	
	$sectionDescription = "Dir $env:WinDir\servicing\packages"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_dir_servicing-packages.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "$env:WinDir\servicing\packages" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription $fileDescription -sectionDescription $sectionDescription

#----------Directory listing: Get registry size info including Config and profile info
	$sectionDescription = "Dir $env:WinDir\system32\config"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_dir_registry_list.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "$env:WinDir\system32\config" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	$CommandToExecute = 'dir /a /s "c:\users\ntuser.dat" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription $fileDescription -sectionDescription $sectionDescription


#---------- Section Windows Store info
	$sectionDescription = "Copying Windows Store logs"
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status $sectionDescription

	$filesToCollect = "$Env:Temp\winstore.log"
	$filesDescription = "$Env:Temp\winstore.log"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}

	$filesToCollect = "$Env:Temp\winstore.log"
	$filesDescription = "$Env:Temp\winstore.log"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}
	
if (test-path "$env:localappdata\Packages\WinStore_cw5n1h2txyewy\AC\Temp\Winstore.log")
{
	CollectFiles -filesToCollect "$env:localappdata\Packages\WinStore_cw5n1h2txyewy\AC\Temp\Winstore.log" -fileDescription "Winstore log" -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
}
if (test-path "$env:localappdata\Temp\WinStore.log")
{
	CollectFiles -filesToCollect "$env:localappdata\Temp\WinStore.log" -fileDescription "Broker log" -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
}
	
#---------- MUSE logs for Win10+
if (get-service usosvc -EA SilentlyContinue)
 {
	$sectionDescription = "Copying MUSE logs for Win10"
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status $sectionDescription

		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Copy UsoPrivate\UpdateStore"
		$DestinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
		Copy-Item "$env:programdata\UsoPrivate\UpdateStore" -Destination $DestinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
		CompressCollectFiles -filesToCollect $DestinationTempFolder -DestinationFileName ($ComputerName + "_UsoPrivate-UpdateStore.zip") -fileDescription "UsoPrivate-UpdateStore Folder" -sectionDescription $sectionDescription -Recursive
		Remove-Item $DestinationTempFolder -Force -Recurse
		
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Copy UsoShared\Logs"
		$DestinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
		Copy-Item "$env:programdata\USOShared\Logs" -Destination $DestinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
		CompressCollectFiles -filesToCollect $DestinationTempFolder -DestinationFileName ($ComputerName + "_USOShared-Logs.zip") -fileDescription "USOShared-Logs Folder" -sectionDescription $sectionDescription -Recursive
		Remove-Item $DestinationTempFolder -Force -Recurse
		
	  # robocopy %_OLDPROGRAMDATA%\USOPrivate\UpdateStore %_TEMPDIR%\Windows.old\MUSE %_ROBOCOPY_PARAMS% /S > nul
	  # robocopy %_OLDPROGRAMDATA%\USOShared\Logs %_TEMPDIR%\Windows.old\MUSE %_ROBOCOPY_PARAMS% /S > nul

	$sectionDescription = "SCHTASKS /query /v /TN \Microsoft\Windows\UpdateOrchestrator\"
		$OutputFile = Join-Path $pwd.path ($ComputerName + "_MUSE_ScheduledTasks.txt")
		Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "MUSE ScheduledTasks"
		$CommandToExecute = 'SCHTASKS /query /v /TN \Microsoft\Windows\UpdateOrchestrator\ '
		RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
		collectfiles -filesToCollect $OutputFile -fileDescription "MUSE: ScheduledTasks" -sectionDescription $sectionDescription
}
#---------- Section Delivery Optimizaton logs and powershell for Win10+
if (get-service dosvc -EA SilentlyContinue) {
	$sectionDescription = "Copying DeliveryOptimization logs"
	if (test-path "$Env:windir\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Logs" )
	{
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Copy DeliveryOptimization\Logs"
		$arrDOlogsFiles = get-childitem -force -path (join-path $Env:windir "ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Logs") -recurse -include *.log,*.etl | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
		CompressCollectFiles -filesToCollect $arrDOlogsFiles -fileDescription "DeliveryOptimization\Logs folder" -sectionDescription "DeliveryOptimization\Logs Folder" -DestinationFileName ($MachineName + "DeliveryOptimization-logs.zip") -RenameOutput $true -recursive 
	}
	if (test-path "$Env:windir\SoftwareDistribution\DeliveryOptimization\SavedLogs" )
	{
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Copy DeliveryOptimization\SavedLogs"
		$arrDOsavedLogsFiles = get-childitem -force -path (join-path $Env:windir "SoftwareDistribution\DeliveryOptimization\SavedLogs") -recurse -include *.log,*.etl | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
		CompressCollectFiles -filesToCollect $arrDOsavedLogsFiles -fileDescription "DeliveryOptimization\SavedLogs folder" -sectionDescription "DeliveryOptimization\SavedLogs Folder" -DestinationFileName ($MachineName + "DeliveryOptimization-SavedLogslogs.zip") -RenameOutput $true -recursive 
	}
}
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Get DeliveryOptimization Registry"
	$OutputFile= $ComputerName + "_reg_DeliveryOptimization.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\DeliveryOptimization" -OutputFile $OutputFile -fileDescription "DeliveryOptimization Reg key" -Recursive $true
	
	$OutputFile = $ComputerName + "_DeliveryOptimization_info.txt"
	Get-DeliveryOptimizationPerfSnap -Debug -Verbose | Out-File -FilePath $OutputFile -append 
	Get-DeliveryOptimizationStatus -Debug -Verbose | Out-File -FilePath $OutputFile -append 
 
#---------- Windows Upgrade logs, see *.ps1


#W8/WS2012 and later
if ($bn -gt 9000)
{
	#----------Event Logs - Windows Setup 
	$sectionDescription = "Event Logs - Windows Store Apps"
	$EventLogNames = "Setup", "Microsoft-Windows-WMI-Activity/Operational", "Microsoft-Windows-Setup/Analytic", "General Logging", "HardwareEvents", "Microsoft-Windows-Crashdump/Operational", "Microsoft-Windows-Dism-Api/Analytic", "Microsoft-Windows-EventLog-WMIProvider/Debug", "Microsoft-Windows-EventLog/Analytic", "Microsoft-Windows-EventLog/Debug", "Microsoft-Windows-Kernel-Boot/Operational" 
	$Prefix = "_evt_"
	$Suffix = ""
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
}
 
#----------  Disk Info
$OutputFile = Join-Path $pwd.path ($Env:ComputerName + "_Storage_Info.txt")
Get-PhysicalDisk  | Out-File -FilePath $OutputFile -append
$Pdisk= Get-PhysicalDisk 
ForEach ( $LDisk in $PDisk )
                {
                $LDisk.FriendlyName | Out-File -FilePath $OutputFile -append
                $LDisk.HealthStatus | Out-File -FilePath $OutputFile -append
                $LDisk | Get-StorageReliabilityCounter | Select-Object * | FL | Out-File -FilePath $OutputFile -append
                "==================" | Out-File -FilePath $OutputFile -append 
                } 

#---------- Running process info
Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Getting Process info"

	$sectionDescription = "Process_and_Service_Tasklist"
		$OutputFile = Join-Path $pwd.path ($ComputerName + "_Process_and_Service_info.txt")
		Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "Process_and_Service_Tasklist"
		$CommandToExecute = 'tasklist /svc /fo list'
		RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
		$CommandToExecute = 'tasklist /v'
		RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
		$CommandToExecute = 'tasklist /M'
		RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
		collectfiles -filesToCollect $OutputFile -fileDescription "Process_and_Service_Tasklist" -sectionDescription $sectionDescription

	$sectionDescription = "Process_and_Service_info"
		$OutputFile = Join-Path $pwd.path ($ComputerName + "_Process_and_Service_info.txt")
		Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "Process_and_Service_info"
		$CommandToExecute = 'wmic process get * /format:texttable'
		RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
		collectfiles -filesToCollect $OutputFile -fileDescription "Process_and_Service_info" -sectionDescription $sectionDescription


Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Getting app list"
if ($bn -gt 9000) {
	$OutputFile = Join-Path $pwd.path ($Env:ComputerName + "_GetAppxPackage.txt")
	import-module appx;get-appxpackage -allusers | Out-File -FilePath $OutputFile -append
}
if ($bn -gt 9600) {
	$OutputFile = Join-Path $pwd.path ($Env:ComputerName + "_GetAppxPackageBundle.txt")
	get-appxpackage -packagetype bundle | Out-File -FilePath $OutputFile -append
	
	$sectionDescription = "Dism /Get-ProvisionedAppxPackages"
		$OutputFile = Join-Path $pwd.path ($ComputerName + "_GetAppxProvisioned.txt")
		Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status $sectionDescription
		$CommandToExecute = 'dism /online /Get-ProvisionedAppxPackages'
		RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
		collectfiles -filesToCollect $OutputFile -fileDescription "$CommandToExecute" -sectionDescription $sectionDescription
}


Write-verbose "$(Get-Date -UFormat "%R:%S") :   end of script DC_Setup_Addons.ps1"

# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBRsbwdOQhVtLYL
# VzYNiq3i+Gt3Xx/YPmZCj1BAeSJY8aCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgak+Hv5lW
# WBIV+EEb4Nua3447QJllAvCHbrOGEg209rEwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBALAnwPUGV16kEv0u0jj0ZiQw4CF/hx0ksyf6oWX3oBCv0amfyrBYT4/r
# QMfueZ4pEJ1kj35gh0J/L+HGsN8Vf4Pgwlj4/SI42XgAxSjxNjNtAY3YmbvV8RBv
# F6ZtTh9ibDqFiD/oD/CFuzcwwbcOUQY2nkw8r0IExadVRNa/9S04Jp5Dm53UMKg0
# +Qgm671SCuGd0sWxVkqILHMvsU4SxYEIjBh0EE5xGRqGCxuSA1uyvEgXZqh+tyAk
# h28KTfIG3NRelTSB2oeOKo16gLE2J23ku3+eNWSNGKjfsM+Jz/wRenzeefjZbESz
# MmbsAv1a31EhlzovkmMoqgEdWfyZCpuhghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgIgyvkHhUeWlNBl2G5it0AoMNB7Ulu1Ad1WApomD6L3ECBmBjK796
# VRgTMjAyMTA1MTkyMjI0NTMuODIyWjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjBB
# NTYtRTMyOS00RDREMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFbfLC6NGc3wacAAAAAAVswDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjE2WhcNMjIwNDExMTkwMjE2WjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjBBNTYtRTMyOS00RDRE
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyCR/pez12qF6y6YuW2eXqXCOIPWOH4in
# P/qPmrkJDNKdtpW6jgqIKJKmvla2qpWUPudP/dZfpXq9yk1BXlx21VXBp82kuffI
# X59E2hRaHVD27xcaJJfxjNVLyrrwk8WJE7gczMyksJpKNx9Bkh3oKK6TItCu4qdI
# XB0aEzETsYJrJpDxkPIQ8ez8LbHgABgwWxU6yxJ1HyNvx/MB6TdI2Vm1Up3QpvyK
# j7deRDngy9RdX1xUvX94N1dVUEGo6EfOgmzL5zbL+zdb6ARfxBv079uMGRHqEho7
# AQDDs27jT9MxV/BcnuDlH8c1cK3tzghqM03hb4K6B7KwudhupGZb6QIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFGXnLTWIbbdTIF1Mf/XlOcmYuqsuMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAKczazumExqZzhB1WiWs7VldGIMxRV2C73/KryDuQhWX
# 5+SVRXZWWi63r5+k6oAad7Ay3B6cW1qBWFUnwdq7w3CT4gCEHQHTgOhs0PDu/goR
# MBF/wo3yBMfoHtGMeGt4wNaDuJxXQOyiPwwgDwCKtaXB/ievykofSfasROx4EkNZ
# zd1tTQhMkQfVHMWEaRbsjM09AI7XrlOns0udeniZpnOhXHw/KI407p/INmvTKpW6
# H06pYf589lhD9hgXKHHL6EdY66pilzzc+GfW8DQB7X5afhud7pkaM/FEjqzGwwiR
# 0FcPQckvI3th9Kts5UBjCNhY4et6wZm6+gRoSANFZSswggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjBBNTYtRTMyOS00
# RDREMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQAKu0FupjLSv5gYu1RoVVFb9iHupqCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5E+T3TAiGA8y
# MDIxMDUxOTE3NDA0NVoYDzIwMjEwNTIwMTc0MDQ1WjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDkT5PdAgEAMAoCAQACAiXuAgH/MAcCAQACAhHFMAoCBQDkUOVdAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAT6AZfuhR8iXXLvZ/xv6pJmYSEXcj
# NLFmlk/HgM+RY6PXQiAteS9wQgzADTsA2Bx1Q0iS26SJQPFGyn/hDkSAPP0itnGu
# lBvk4f9hVN4AOYjjAEzVevPR+937YyY4K7iyXyxLajgimFrItg60vXEw8ionAcFU
# bM6+CcrK5lspbeUxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAVt8sLo0ZzfBpwAAAAABWzANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCAi4E0t
# gdls08OBNJyHRnuG0p3lMY4Ci7KpTYQqOw/pjzCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIMki4KkoYxGHiUIa5wY8cI0nuOr0xNt7eZDYW1JksIUZMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFbfLC6NGc3wacA
# AAAAAVswIgQgAm6ptZhoV0ZX/k1qrDo7mjQEEY7cbOeVl7Ux9kzlqdAwDQYJKoZI
# hvcNAQELBQAEggEAF1UAX8+hONukzifguRfTLFvnC/mzNYLfyOB+zHL9XuOad33w
# Njj2ltLohUiaVWb3osJ97DRQH3RAkRbSa/NnI6UewX5uPU43fjmn5nu79ARSxu+/
# gpFcus9Ydr58RTh4AeNyVkvHtyG+6m9a6UJBGrxRbaZPZaCMP4pJIiXLXSq1Vpdx
# B7nuHlKiMgRHfHKGsE0pm8vXN65ZTKbpEAq+PTS1ufUinh3Vp8w6n3mmDkF3ozGm
# Iyb/OgZD34wzke/bFiXgW6PUUkVTOJXjGGKl/UoH36FE8SUtUti1R8wi6pV8Gli+
# jZft/gzP1G5mL9p1Ce4+ulF2TXsNDnvy9LgHaQ==
# SIG # End signature block
